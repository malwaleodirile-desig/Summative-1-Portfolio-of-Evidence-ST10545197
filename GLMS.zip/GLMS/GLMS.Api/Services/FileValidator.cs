using System.Text;

namespace GLMS.Api.Services;

/// <summary>Validates uploaded signed agreements. Only genuine PDF files are accepted.</summary>
public static class FileValidator
{
    public const long MaxFileSizeBytes = 10 * 1024 * 1024; // 10 MB

    private static readonly byte[] PdfSignature = Encoding.ASCII.GetBytes("%PDF-");

    /// <exception cref="InvalidFileException">Thrown when the file is missing, empty, too large, not a .pdf, or not really a PDF.</exception>
    public static void ValidatePdf(string? fileName, long length, Stream? content = null)
    {
        if (string.IsNullOrWhiteSpace(fileName))
        {
            throw new InvalidFileException("No file was selected.");
        }

        var extension = Path.GetExtension(fileName);
        if (!string.Equals(extension, ".pdf", StringComparison.OrdinalIgnoreCase))
        {
            var shown = string.IsNullOrEmpty(extension) ? "files without an extension" : $"'{extension}' files";
            throw new InvalidFileException($"Only PDF files are allowed. {shown} cannot be uploaded.");
        }

        if (length <= 0)
        {
            throw new InvalidFileException("The selected file is empty.");
        }

        if (length > MaxFileSizeBytes)
        {
            throw new InvalidFileException("The file is too large. The maximum size is 10 MB.");
        }

        // Defence in depth: the extension can be faked, so also check the PDF "magic number".
        if (content is { CanSeek: true })
        {
            var buffer = new byte[PdfSignature.Length];
            var total = 0;
            while (total < buffer.Length)
            {
                var read = content.Read(buffer, total, buffer.Length - total);
                if (read == 0)
                {
                    break;
                }

                total += read;
            }

            content.Position = 0;

            if (total < buffer.Length || !buffer.SequenceEqual(PdfSignature))
            {
                throw new InvalidFileException("The file content is not a valid PDF document.");
            }
        }
    }
}
