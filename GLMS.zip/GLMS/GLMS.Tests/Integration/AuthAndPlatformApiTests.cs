using System.Net;
using System.Net.Http.Json;
using GLMS.Api.Dtos;
using GLMS.Api.Data;

namespace GLMS.Tests.Integration;

/// <summary>Security, health, Swagger and the supporting endpoints.</summary>
public class AuthAndPlatformApiTests : IClassFixture<GlmsApiFactory>
{
    private readonly GlmsApiFactory _factory;

    public AuthAndPlatformApiTests(GlmsApiFactory factory)
    {
        _factory = factory;
    }

    [Fact]
    public async Task Health_ReturnsOk_WithoutAToken()
    {
        var response = await _factory.CreateClient().GetAsync("/health");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }

    [Fact]
    public async Task Swagger_Document_IsPublishedAndDescribesTheContractEndpoints()
    {
        var response = await _factory.CreateClient().GetAsync("/swagger/v1/swagger.json");
        var json = await response.Content.ReadAsStringAsync();

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        Assert.Contains("/api/contracts", json);
        Assert.Contains("/api/contracts/{id}/status", json);
        Assert.Contains("\"Bearer\"", json);
    }

    [Fact]
    public async Task Login_ValidCredentials_ReturnsJwtToken()
    {
        var response = await _factory.CreateClient().PostAsJsonAsync("/api/auth/login",
            new { username = DbSeeder.AdminUsername, password = DbSeeder.AdminPassword });

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var body = await ApiTestHelpers.ReadAsync<LoginResponse>(response);
        Assert.False(string.IsNullOrWhiteSpace(body.Token));
        Assert.Equal(3, body.Token.Split('.').Length); // header.payload.signature
        Assert.Equal("Admin", body.Role);
        Assert.True(body.ExpiresAtUtc > DateTime.UtcNow);
    }

    [Theory]
    [InlineData("admin", "wrong-password")]
    [InlineData("nobody", "Admin@123")]
    [InlineData("", "")]
    public async Task Login_InvalidCredentials_Returns401(string username, string password)
    {
        var response = await _factory.CreateClient().PostAsJsonAsync("/api/auth/login", new { username, password });

        Assert.True(response.StatusCode is HttpStatusCode.Unauthorized or HttpStatusCode.BadRequest);
    }

    [Theory]
    [InlineData("/api/contracts")]
    [InlineData("/api/clients")]
    [InlineData("/api/servicerequests")]
    [InlineData("/api/dashboard")]
    [InlineData("/api/currency/usd-zar")]
    public async Task ProtectedEndpoints_WithoutToken_Return401(string url)
    {
        var response = await _factory.CreateClient().GetAsync(url);

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task ProtectedEndpoint_WithGarbageToken_Returns401()
    {
        var client = _factory.CreateClient();
        client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", "not.a.token");

        var response = await client.GetAsync("/api/contracts");

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Me_ReturnsSignedInUser()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);

        var response = await client.GetAsync("/api/auth/me");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var me = await ApiTestHelpers.ReadAsync<UserInfoDto>(response);
        Assert.Equal("manager", me.Username);
        Assert.Equal("Manager", me.Role);
    }

    [Fact]
    public async Task Currency_UsdToZar_ReturnsRateAsJson()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);

        var response = await client.GetAsync("/api/currency/usd-zar");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var rate = await ApiTestHelpers.ReadAsync<ExchangeRateDto>(response);
        Assert.Equal(GlmsApiFactory.FixedRate, rate.Rate);
        Assert.Equal("USD", rate.From);
        Assert.Equal("ZAR", rate.To);
    }

    [Fact]
    public async Task Currency_WhenProviderIsDown_Returns503()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);
        _factory.Currency.Fail = true;
        try
        {
            var response = await client.GetAsync("/api/currency/usd-zar");

            Assert.Equal(HttpStatusCode.ServiceUnavailable, response.StatusCode);
        }
        finally
        {
            _factory.Currency.Fail = false;
        }
    }

    [Fact]
    public async Task Dashboard_ReturnsCountsFromSeededData()
    {
        var client = await ApiTestHelpers.AdminAsync(_factory);

        var response = await client.GetAsync("/api/dashboard");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var dashboard = await ApiTestHelpers.ReadAsync<DashboardDto>(response);
        Assert.True(dashboard.ClientCount >= 3);
        Assert.True(dashboard.ContractCount >= 5);
        Assert.True(dashboard.ActiveContracts >= 2);
        Assert.True(dashboard.ExpiredContracts >= 1);
    }

    [Fact]
    public async Task Clients_Create_Returns201_AndCanBeReadBack()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);

        var created = await client.PostAsJsonAsync("/api/clients",
            new { name = "Integration Test Client", contactDetails = "it@example.com", region = "Test Region" });

        Assert.Equal(HttpStatusCode.Created, created.StatusCode);
        Assert.NotNull(created.Headers.Location);
        var dto = await ApiTestHelpers.ReadAsync<ClientDto>(created);

        var fetched = await client.GetAsync($"/api/clients/{dto.Id}");
        Assert.Equal(HttpStatusCode.OK, fetched.StatusCode);
        Assert.Equal("Integration Test Client", (await ApiTestHelpers.ReadAsync<ClientDto>(fetched)).Name);
    }

    [Fact]
    public async Task Clients_Create_WithMissingFields_Returns400()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);

        var response = await client.PostAsJsonAsync("/api/clients", new { name = "", contactDetails = "", region = "" });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Clients_Delete_AsManager_IsForbidden()
    {
        var manager = await ApiTestHelpers.ManagerAsync(_factory);
        var clientId = await ApiTestHelpers.FirstClientIdAsync(manager);

        var response = await manager.DeleteAsync($"/api/clients/{clientId}");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Clients_Delete_WhenClientHasContracts_Returns400()
    {
        var admin = await ApiTestHelpers.AdminAsync(_factory);
        var clientId = await ApiTestHelpers.FirstClientIdAsync(admin); // seeded clients all have contracts

        var response = await admin.DeleteAsync($"/api/clients/{clientId}");

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Clients_Delete_NewClientWithoutContracts_Returns204()
    {
        var admin = await ApiTestHelpers.AdminAsync(_factory);
        var created = await admin.PostAsJsonAsync("/api/clients",
            new { name = "Disposable Client", contactDetails = "x@example.com", region = "Nowhere" });
        var dto = await ApiTestHelpers.ReadAsync<ClientDto>(created);

        var response = await admin.DeleteAsync($"/api/clients/{dto.Id}");

        Assert.Equal(HttpStatusCode.NoContent, response.StatusCode);
    }
}
