using GLMS.Api.Data;
using GLMS.Api.Dtos;
using GLMS.Api.Models;
using GLMS.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GLMS.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class DashboardController : ControllerBase
{
    private readonly GlmsDbContext _db;
    private readonly IContractService _contracts;

    public DashboardController(GlmsDbContext db, IContractService contracts)
    {
        _db = db;
        _contracts = contracts;
    }

    /// <summary>Headline numbers for the dashboard.</summary>
    [HttpGet]
    public async Task<ActionResult<DashboardDto>> Get(CancellationToken ct)
    {
        await _contracts.RefreshExpiredContractsAsync(ct);

        return new DashboardDto
        {
            ClientCount = await _db.Clients.CountAsync(ct),
            ContractCount = await _db.Contracts.CountAsync(ct),
            DraftContracts = await _db.Contracts.CountAsync(c => c.Status == ContractStatus.Draft, ct),
            ActiveContracts = await _db.Contracts.CountAsync(c => c.Status == ContractStatus.Active, ct),
            OnHoldContracts = await _db.Contracts.CountAsync(c => c.Status == ContractStatus.OnHold, ct),
            ExpiredContracts = await _db.Contracts.CountAsync(c => c.Status == ContractStatus.Expired, ct),
            RequestCount = await _db.ServiceRequests.CountAsync(ct),
            TotalZar = await _db.ServiceRequests
                .Where(r => r.Status != RequestStatus.Cancelled)
                .SumAsync(r => r.CostZar, ct)
        };
    }
}
