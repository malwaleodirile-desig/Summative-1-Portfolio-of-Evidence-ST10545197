using System.Globalization;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using GLMS.Web.Models;

namespace GLMS.Web.Services;

// ------------------------------------------------------------------ Exceptions
public class ApiException : Exception
{
    public int StatusCode { get; }

    public ApiException(int statusCode, string message) : base(message)
    {
        StatusCode = statusCode;
    }
}

/// <summary>The API rejected the request because of a validation or business rule (HTTP 400, 409 or 422).</summary>
public class ApiValidationException : ApiException
{
    public ApiValidationException(int statusCode, string message) : base(statusCode, message)
    {
    }
}

public class ApiUnauthorizedException : ApiException
{
    public ApiUnauthorizedException(string message) : base(401, message)
    {
    }
}

public class ApiForbiddenException : ApiException
{
    public ApiForbiddenException(string message) : base(403, message)
    {
    }
}

public class ApiNotFoundException : ApiException
{
    public ApiNotFoundException(string message) : base(404, message)
    {
    }
}

// ------------------------------------------------------------------ Contract
public interface IGlmsApiClient
{
    Task<LoginResult?> LoginAsync(string username, string password, CancellationToken ct = default);
    Task<DashboardModel> GetDashboardAsync(CancellationToken ct = default);

    Task<List<ClientModel>> GetClientsAsync(CancellationToken ct = default);
    Task<ClientModel?> GetClientAsync(int id, CancellationToken ct = default);
    Task<ClientModel> CreateClientAsync(ClientFormModel client, CancellationToken ct = default);
    Task<ClientModel> UpdateClientAsync(int id, ClientFormModel client, CancellationToken ct = default);
    Task DeleteClientAsync(int id, CancellationToken ct = default);

    Task<List<ContractModel>> SearchContractsAsync(ContractSearchCriteria criteria, CancellationToken ct = default);
    Task<ContractModel?> GetContractAsync(int id, CancellationToken ct = default);
    Task<ContractModel> CreateContractAsync(ContractSubmission contract, CancellationToken ct = default);
    Task<ContractModel> UpdateContractAsync(int id, ContractSubmission contract, CancellationToken ct = default);
    Task<ContractModel> ChangeContractStatusAsync(int id, ContractStatus status, CancellationToken ct = default);
    Task<ContractModel> UploadAgreementAsync(int id, IFormFile file, CancellationToken ct = default);
    Task<byte[]?> DownloadAgreementAsync(int id, CancellationToken ct = default);

    Task<List<ServiceRequestModel>> GetServiceRequestsAsync(int? contractId = null, CancellationToken ct = default);
    Task<ServiceRequestModel> CreateServiceRequestAsync(int contractId, string description, decimal costUsd,
        CancellationToken ct = default);
    Task<ServiceRequestModel> ChangeRequestStatusAsync(int id, RequestStatus status, CancellationToken ct = default);

    Task<ExchangeRateModel> GetUsdToZarRateAsync(CancellationToken ct = default);
}

/// <summary>
/// The only way the MVC app reaches data: HTTP calls to the GLMS API. The JWT is attached to every
/// request by <see cref="AuthTokenHandler"/>.
/// </summary>
public class GlmsApiClient : IGlmsApiClient
{
    private static readonly JsonSerializerOptions Json = CreateJsonOptions();
    private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

    private readonly HttpClient _http;

    public GlmsApiClient(HttpClient http)
    {
        _http = http;
    }

    private static JsonSerializerOptions CreateJsonOptions()
    {
        var options = new JsonSerializerOptions(JsonSerializerDefaults.Web);
        options.Converters.Add(new JsonStringEnumConverter());
        return options;
    }

    // ------------------------------------------------------------ Auth
    public async Task<LoginResult?> LoginAsync(string username, string password, CancellationToken ct = default)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, "api/auth/login")
        {
            Content = JsonContent.Create(new { username, password }, options: Json)
        };

        using var response = await _http.SendAsync(request, ct);
        if (response.StatusCode == HttpStatusCode.Unauthorized)
        {
            return null;
        }

        await EnsureSuccessAsync(response, ct);
        return await response.Content.ReadFromJsonAsync<LoginResult>(Json, ct);
    }

    public Task<DashboardModel> GetDashboardAsync(CancellationToken ct = default) =>
        GetAsync<DashboardModel>("api/dashboard", ct);

    // ------------------------------------------------------------ Clients
    public Task<List<ClientModel>> GetClientsAsync(CancellationToken ct = default) =>
        GetAsync<List<ClientModel>>("api/clients", ct);

    public async Task<ClientModel?> GetClientAsync(int id, CancellationToken ct = default)
    {
        try
        {
            return await GetAsync<ClientModel>($"api/clients/{id}", ct);
        }
        catch (ApiNotFoundException)
        {
            return null;
        }
    }

    public Task<ClientModel> CreateClientAsync(ClientFormModel client, CancellationToken ct = default) =>
        SendJsonAsync<ClientModel>(HttpMethod.Post, "api/clients", client, ct);

    public Task<ClientModel> UpdateClientAsync(int id, ClientFormModel client, CancellationToken ct = default) =>
        SendJsonAsync<ClientModel>(HttpMethod.Put, $"api/clients/{id}", client, ct);

    public async Task DeleteClientAsync(int id, CancellationToken ct = default)
    {
        using var request = new HttpRequestMessage(HttpMethod.Delete, $"api/clients/{id}");
        using var response = await _http.SendAsync(request, ct);
        await EnsureSuccessAsync(response, ct);
    }

    // ------------------------------------------------------------ Contracts
    public Task<List<ContractModel>> SearchContractsAsync(ContractSearchCriteria criteria, CancellationToken ct = default)
    {
        var query = new List<string>();
        if (criteria.From.HasValue) query.Add("from=" + criteria.From.Value.ToString("yyyy-MM-dd", Inv));
        if (criteria.To.HasValue) query.Add("to=" + criteria.To.Value.ToString("yyyy-MM-dd", Inv));
        if (criteria.Status.HasValue) query.Add("status=" + criteria.Status.Value);
        if (criteria.ClientId.HasValue) query.Add("clientId=" + criteria.ClientId.Value.ToString(Inv));
        if (!string.IsNullOrWhiteSpace(criteria.ClientName))
            query.Add("clientName=" + Uri.EscapeDataString(criteria.ClientName.Trim()));

        var url = "api/contracts" + (query.Count > 0 ? "?" + string.Join("&", query) : string.Empty);
        return GetAsync<List<ContractModel>>(url, ct);
    }

    public async Task<ContractModel?> GetContractAsync(int id, CancellationToken ct = default)
    {
        try
        {
            return await GetAsync<ContractModel>($"api/contracts/{id}", ct);
        }
        catch (ApiNotFoundException)
        {
            return null;
        }
    }

    public async Task<ContractModel> CreateContractAsync(ContractSubmission contract, CancellationToken ct = default)
    {
        using var form = BuildContractForm(contract);
        using var request = new HttpRequestMessage(HttpMethod.Post, "api/contracts") { Content = form };
        return await SendAsync<ContractModel>(request, ct);
    }

    public async Task<ContractModel> UpdateContractAsync(int id, ContractSubmission contract, CancellationToken ct = default)
    {
        using var form = BuildContractForm(contract);
        using var request = new HttpRequestMessage(HttpMethod.Put, $"api/contracts/{id}") { Content = form };
        return await SendAsync<ContractModel>(request, ct);
    }

    public Task<ContractModel> ChangeContractStatusAsync(int id, ContractStatus status, CancellationToken ct = default) =>
        SendJsonAsync<ContractModel>(HttpMethod.Patch, $"api/contracts/{id}/status", new { status }, ct);

    public async Task<ContractModel> UploadAgreementAsync(int id, IFormFile file, CancellationToken ct = default)
    {
        using var form = new MultipartFormDataContent();
        AddFile(form, "file", file);
        using var request = new HttpRequestMessage(HttpMethod.Post, $"api/contracts/{id}/agreement") { Content = form };
        return await SendAsync<ContractModel>(request, ct);
    }

    public async Task<byte[]?> DownloadAgreementAsync(int id, CancellationToken ct = default)
    {
        using var response = await _http.GetAsync($"api/contracts/{id}/agreement", ct);
        if (response.StatusCode == HttpStatusCode.NotFound)
        {
            return null;
        }

        await EnsureSuccessAsync(response, ct);
        return await response.Content.ReadAsByteArrayAsync(ct);
    }

    // ------------------------------------------------------------ Service requests
    public Task<List<ServiceRequestModel>> GetServiceRequestsAsync(int? contractId = null, CancellationToken ct = default) =>
        GetAsync<List<ServiceRequestModel>>(
            contractId.HasValue ? $"api/servicerequests?contractId={contractId.Value}" : "api/servicerequests", ct);

    public Task<ServiceRequestModel> CreateServiceRequestAsync(int contractId, string description, decimal costUsd,
        CancellationToken ct = default) =>
        SendJsonAsync<ServiceRequestModel>(HttpMethod.Post, "api/servicerequests",
            new { contractId, description, costUsd }, ct);

    public Task<ServiceRequestModel> ChangeRequestStatusAsync(int id, RequestStatus status, CancellationToken ct = default) =>
        SendJsonAsync<ServiceRequestModel>(HttpMethod.Patch, $"api/servicerequests/{id}/status", new { status }, ct);

    public Task<ExchangeRateModel> GetUsdToZarRateAsync(CancellationToken ct = default) =>
        GetAsync<ExchangeRateModel>("api/currency/usd-zar", ct);

    // ------------------------------------------------------------ Helpers
    private Task<T> GetAsync<T>(string url, CancellationToken ct) =>
        SendAsync<T>(new HttpRequestMessage(HttpMethod.Get, url), ct);

    private async Task<T> SendJsonAsync<T>(HttpMethod method, string url, object body, CancellationToken ct)
    {
        using var request = new HttpRequestMessage(method, url) { Content = JsonContent.Create(body, options: Json) };
        return await SendAsync<T>(request, ct);
    }

    private async Task<T> SendAsync<T>(HttpRequestMessage request, CancellationToken ct)
    {
        using (request)
        using (var response = await _http.SendAsync(request, ct))
        {
            await EnsureSuccessAsync(response, ct);
            var result = await response.Content.ReadFromJsonAsync<T>(Json, ct);
            return result ?? throw new ApiException(502, "The API returned an empty response.");
        }
    }

    private static MultipartFormDataContent BuildContractForm(ContractSubmission s)
    {
        var form = new MultipartFormDataContent
        {
            { new StringContent(s.ClientId.ToString(Inv)), "ClientId" },
            { new StringContent(s.StartDate.ToString("yyyy-MM-dd", Inv)), "StartDate" },
            { new StringContent(s.EndDate.ToString("yyyy-MM-dd", Inv)), "EndDate" },
            { new StringContent(s.Status.ToString()), "Status" },
            { new StringContent(s.ServiceLevel.ToString()), "ServiceLevel" }
        };

        if (s.SignedAgreement != null && !string.IsNullOrEmpty(s.SignedAgreement.FileName))
        {
            AddFile(form, "SignedAgreement", s.SignedAgreement);
        }

        return form;
    }

    private static void AddFile(MultipartFormDataContent form, string fieldName, IFormFile file)
    {
        var content = new StreamContent(file.OpenReadStream());
        content.Headers.ContentType = new MediaTypeHeaderValue(
            string.IsNullOrWhiteSpace(file.ContentType) ? "application/octet-stream" : file.ContentType);
        form.Add(content, fieldName, file.FileName);
    }

    private static async Task EnsureSuccessAsync(HttpResponseMessage response, CancellationToken ct)
    {
        if (response.IsSuccessStatusCode)
        {
            return;
        }

        var message = await ReadErrorAsync(response, ct);
        var status = (int)response.StatusCode;

        if (response.StatusCode == HttpStatusCode.Unauthorized) throw new ApiUnauthorizedException(message);
        if (response.StatusCode == HttpStatusCode.Forbidden) throw new ApiForbiddenException(message);
        if (response.StatusCode == HttpStatusCode.NotFound) throw new ApiNotFoundException(message);
        if (status is 400 or 409 or 422) throw new ApiValidationException(status, message);
        throw new ApiException(status, message);
    }

    /// <summary>Pulls a human-friendly message out of an RFC 7807 problem response.</summary>
    private static async Task<string> ReadErrorAsync(HttpResponseMessage response, CancellationToken ct)
    {
        var fallback = $"The API returned {(int)response.StatusCode} {response.ReasonPhrase}.";

        string body;
        try
        {
            body = await response.Content.ReadAsStringAsync(ct);
        }
        catch (Exception)
        {
            return fallback;
        }

        if (string.IsNullOrWhiteSpace(body))
        {
            return fallback;
        }

        try
        {
            using var doc = JsonDocument.Parse(body);
            var root = doc.RootElement;
            if (root.ValueKind != JsonValueKind.Object)
            {
                return fallback;
            }

            if (root.TryGetProperty("detail", out var detail) && detail.ValueKind == JsonValueKind.String &&
                !string.IsNullOrWhiteSpace(detail.GetString()))
            {
                return detail.GetString()!;
            }

            if (root.TryGetProperty("errors", out var errors) && errors.ValueKind == JsonValueKind.Object)
            {
                var sb = new StringBuilder();
                foreach (var field in errors.EnumerateObject())
                {
                    if (field.Value.ValueKind != JsonValueKind.Array) continue;
                    foreach (var item in field.Value.EnumerateArray())
                    {
                        if (sb.Length > 0) sb.Append(' ');
                        sb.Append(item.GetString());
                    }
                }

                if (sb.Length > 0) return sb.ToString();
            }

            if (root.TryGetProperty("title", out var title) && title.ValueKind == JsonValueKind.String)
            {
                return title.GetString() ?? fallback;
            }
        }
        catch (JsonException)
        {
            // not JSON - fall through
        }

        return fallback;
    }
}
