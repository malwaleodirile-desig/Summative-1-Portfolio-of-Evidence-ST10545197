using GLMS.Api.Models;
using GLMS.Api.Services;
using Microsoft.EntityFrameworkCore;

namespace GLMS.Tests;

public class ServiceRequestServiceTests
{
    private static ServiceRequestService CreateService(Api.Data.GlmsDbContext db, FakeCurrencyService currency) =>
        new(db, currency, new FixedTimeProvider(TestData.Now));

    [Fact]
    public async Task Create_ActiveContract_SavesRequestWithConvertedZarCost()
    {
        using var db = TestData.NewDb();
        var contract = await TestData.AddContractAsync(db, ContractStatus.Active);
        var currency = new FakeCurrencyService { Rate = 18.50m };

        var request = await CreateService(db, currency).CreateAsync(contract.Id, "Ship 2 containers", 100m);

        Assert.Equal(100m, request.CostUsd);
        Assert.Equal(18.50m, request.ExchangeRate);
        Assert.Equal(1850.00m, request.CostZar);
        Assert.Equal(RequestStatus.Pending, request.Status);
        Assert.Equal(1, await db.ServiceRequests.CountAsync());
    }

    [Fact]
    public async Task Create_ExpiredContract_ThrowsAndSavesNothing()
    {
        using var db = TestData.NewDb();
        var contract = await TestData.AddContractAsync(db, ContractStatus.Expired);

        var ex = await Assert.ThrowsAsync<BusinessRuleException>(() =>
            CreateService(db, new FakeCurrencyService()).CreateAsync(contract.Id, "Test", 50m));

        Assert.Contains("Expired", ex.Message);
        Assert.Equal(0, await db.ServiceRequests.CountAsync());
    }

    [Fact]
    public async Task Create_OnHoldContract_ThrowsAndSavesNothing()
    {
        using var db = TestData.NewDb();
        var contract = await TestData.AddContractAsync(db, ContractStatus.OnHold);

        var ex = await Assert.ThrowsAsync<BusinessRuleException>(() =>
            CreateService(db, new FakeCurrencyService()).CreateAsync(contract.Id, "Test", 50m));

        Assert.Contains("On Hold", ex.Message);
        Assert.Equal(0, await db.ServiceRequests.CountAsync());
    }

    [Fact]
    public async Task Create_DraftContract_Throws()
    {
        using var db = TestData.NewDb();
        var contract = await TestData.AddContractAsync(db, ContractStatus.Draft, withAgreement: false);

        await Assert.ThrowsAsync<BusinessRuleException>(() =>
            CreateService(db, new FakeCurrencyService()).CreateAsync(contract.Id, "Test", 50m));
    }

    [Fact]
    public async Task Create_ActiveContractPastEndDate_IsRejectedAndMarkedExpired()
    {
        using var db = TestData.NewDb();
        var contract = await TestData.AddContractAsync(db, ContractStatus.Active,
            start: new DateTime(2025, 1, 1), end: new DateTime(2026, 10, 12));

        await Assert.ThrowsAsync<BusinessRuleException>(() =>
            CreateService(db, new FakeCurrencyService()).CreateAsync(contract.Id, "Test", 50m));

        var reloaded = await db.Contracts.AsNoTracking().SingleAsync(c => c.Id == contract.Id);
        Assert.Equal(ContractStatus.Expired, reloaded.Status);
        Assert.Equal(0, await db.ServiceRequests.CountAsync());
    }

    [Fact]
    public async Task Create_UnknownContract_Throws()
    {
        using var db = TestData.NewDb();

        await Assert.ThrowsAsync<BusinessRuleException>(() =>
            CreateService(db, new FakeCurrencyService()).CreateAsync(999, "Test", 50m));
    }

    [Theory]
    [InlineData("0")]
    [InlineData("-5")]
    public async Task Create_NonPositiveCost_Throws(string cost)
    {
        using var db = TestData.NewDb();
        var contract = await TestData.AddContractAsync(db, ContractStatus.Active);

        await Assert.ThrowsAsync<BusinessRuleException>(() =>
            CreateService(db, new FakeCurrencyService()).CreateAsync(
                contract.Id, "Test", decimal.Parse(cost, System.Globalization.CultureInfo.InvariantCulture)));
    }

    [Fact]
    public async Task Create_EmptyDescription_Throws()
    {
        using var db = TestData.NewDb();
        var contract = await TestData.AddContractAsync(db, ContractStatus.Active);

        await Assert.ThrowsAsync<BusinessRuleException>(() =>
            CreateService(db, new FakeCurrencyService()).CreateAsync(contract.Id, "   ", 50m));
    }

    [Fact]
    public async Task Create_ExchangeRateUnavailable_PropagatesAndSavesNothing()
    {
        using var db = TestData.NewDb();
        var contract = await TestData.AddContractAsync(db, ContractStatus.Active);
        var currency = new FakeCurrencyService { Fail = true };

        await Assert.ThrowsAsync<ExchangeRateUnavailableException>(() =>
            CreateService(db, currency).CreateAsync(contract.Id, "Test", 50m));

        Assert.Equal(0, await db.ServiceRequests.CountAsync());
    }

    [Fact]
    public async Task Create_RejectedContract_NeverCallsTheCurrencyApi()
    {
        using var db = TestData.NewDb();
        var contract = await TestData.AddContractAsync(db, ContractStatus.Expired);
        var currency = new FakeCurrencyService();

        await Assert.ThrowsAsync<BusinessRuleException>(() =>
            CreateService(db, currency).CreateAsync(contract.Id, "Test", 50m));

        Assert.Equal(0, currency.Calls);
    }

    [Fact]
    public async Task ChangeStatus_ValidTransition_UpdatesRequest()
    {
        using var db = TestData.NewDb();
        var contract = await TestData.AddContractAsync(db, ContractStatus.Active);
        var service = CreateService(db, new FakeCurrencyService());
        var request = await service.CreateAsync(contract.Id, "Test", 10m);

        await service.ChangeStatusAsync(request.Id, RequestStatus.InProgress);

        Assert.Equal(RequestStatus.InProgress, (await db.ServiceRequests.SingleAsync()).Status);
    }

    [Fact]
    public async Task ChangeStatus_InvalidTransition_Throws()
    {
        using var db = TestData.NewDb();
        var contract = await TestData.AddContractAsync(db, ContractStatus.Active);
        var service = CreateService(db, new FakeCurrencyService());
        var request = await service.CreateAsync(contract.Id, "Test", 10m);

        await Assert.ThrowsAsync<BusinessRuleException>(() =>
            service.ChangeStatusAsync(request.Id, RequestStatus.Completed));
    }
}
