using GLMS.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace GLMS.Api.Data;

public class GlmsDbContext : DbContext
{
    public GlmsDbContext(DbContextOptions<GlmsDbContext> options) : base(options)
    {
    }

    public DbSet<AppUser> AppUsers => Set<AppUser>();
    public DbSet<Client> Clients => Set<Client>();
    public DbSet<Contract> Contracts => Set<Contract>();
    public DbSet<ServiceRequest> ServiceRequests => Set<ServiceRequest>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AppUser>(e =>
        {
            e.Property(u => u.Username).HasMaxLength(100);
            e.Property(u => u.PasswordHash).HasMaxLength(500);
            e.Property(u => u.Role).HasMaxLength(50);
            e.HasIndex(u => u.Username).IsUnique();
        });

        modelBuilder.Entity<Contract>(e =>
        {
            e.HasOne(c => c.Client)
                .WithMany(c => c.Contracts)
                .HasForeignKey(c => c.ClientId)
                .OnDelete(DeleteBehavior.Restrict);

            e.Property(c => c.SignedAgreementOriginalName).HasMaxLength(260);
            e.Property(c => c.SignedAgreementStoredName).HasMaxLength(100);
            e.HasIndex(c => new { c.Status, c.EndDate });
        });

        modelBuilder.Entity<ServiceRequest>(e =>
        {
            e.HasOne(r => r.Contract)
                .WithMany(c => c.ServiceRequests)
                .HasForeignKey(r => r.ContractId)
                .OnDelete(DeleteBehavior.Restrict);

            e.Property(r => r.CostUsd).HasPrecision(18, 2);
            e.Property(r => r.ExchangeRate).HasPrecision(18, 6);
            e.Property(r => r.CostZar).HasPrecision(18, 2);
        });
    }
}
