using GLMS.Api.Models;

namespace GLMS.Api.Services;

/// <summary>Allowed status changes for a contract.</summary>
public static class ContractWorkflow
{
    private static readonly Dictionary<ContractStatus, ContractStatus[]> Allowed = new()
    {
        [ContractStatus.Draft] = new[] { ContractStatus.Active },
        [ContractStatus.Active] = new[] { ContractStatus.OnHold, ContractStatus.Expired },
        [ContractStatus.OnHold] = new[] { ContractStatus.Active, ContractStatus.Expired },
        [ContractStatus.Expired] = Array.Empty<ContractStatus>()
    };

    public static IReadOnlyList<ContractStatus> AllowedNext(ContractStatus from) => Allowed[from];

    public static bool CanTransition(ContractStatus from, ContractStatus to) =>
        from == to || Allowed[from].Contains(to);
}

/// <summary>Allowed status changes for a service request.</summary>
public static class RequestWorkflow
{
    private static readonly Dictionary<RequestStatus, RequestStatus[]> Allowed = new()
    {
        [RequestStatus.Pending] = new[] { RequestStatus.InProgress, RequestStatus.Cancelled },
        [RequestStatus.InProgress] = new[] { RequestStatus.Completed, RequestStatus.Cancelled },
        [RequestStatus.Completed] = Array.Empty<RequestStatus>(),
        [RequestStatus.Cancelled] = Array.Empty<RequestStatus>()
    };

    public static IReadOnlyList<RequestStatus> AllowedNext(RequestStatus from) => Allowed[from];

    public static bool CanTransition(RequestStatus from, RequestStatus to) =>
        from == to || Allowed[from].Contains(to);
}
