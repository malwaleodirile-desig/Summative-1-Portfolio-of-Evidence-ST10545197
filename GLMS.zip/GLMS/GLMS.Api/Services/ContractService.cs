using GLMS.Api.Data;
using GLMS.Api.Helpers;
using GLMS.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace GLMS.Api.Services;

public record AgreementUpload(string FileName, long Length, Stream Content);

public interface IContractService
{
    Task<Contract> CreateAsync(Contract contract, AgreementUpload? agreement, CancellationToken ct = default);
    Task UpdateAsync(Contract edited, AgreementUpload? agreement, CancellationToken ct = default);
    Task ChangeStatusAsync(int contractId, ContractStatus newStatus, CancellationToken ct = default);
    Task AttachAgreementAsync(int contractId, AgreementUpload agreement, CancellationToken ct = default);
    Task<int> RefreshExpiredContractsAsync(CancellationToken ct = default);
    Task<List<Contract>> SearchAsync(ContractSearchCriteria criteria, CancellationToken ct = default);
}

public class ContractService : IContractService
{
    private readonly GlmsDbContext _db;
    private readonly IFileStorageService _files;
    private readonly TimeProvider _time;

    public ContractService(GlmsDbContext db, IFileStorageService files, TimeProvider time)
    {
        _db = db;
        _files = files;
        _time = time;
    }

    public async Task<Contract> CreateAsync(Contract contract, AgreementUpload? agreement,
        CancellationToken ct = default)
    {
        ValidateBasics(contract);
        await EnsureClientExistsAsync(contract.ClientId, ct);

        // Validate the file BEFORE touching the database or disk.
        if (agreement != null)
        {
            FileValidator.ValidatePdf(agreement.FileName, agreement.Length, agreement.Content);
        }

        if (contract.Status == ContractStatus.Active)
        {
            if (agreement == null)
            {
                throw new BusinessRuleException("A signed agreement (PDF) must be uploaded before a contract can be Active.");
            }

            RequireNotPastEndDate(contract);
        }

        contract.StartDate = contract.StartDate.Date;
        contract.EndDate = contract.EndDate.Date;

        StoredFile? stored = null;
        if (agreement != null)
        {
            stored = await _files.SaveSignedAgreementAsync(agreement.FileName, agreement.Length, agreement.Content, ct);
            ApplyAgreement(contract, stored);
        }

        _db.Contracts.Add(contract);
        try
        {
            await _db.SaveChangesAsync(ct);
        }
        catch
        {
            if (stored != null)
            {
                _files.Delete(stored.StoredName);
            }

            throw;
        }

        return contract;
    }

    public async Task UpdateAsync(Contract edited, AgreementUpload? agreement, CancellationToken ct = default)
    {
        var existing = await _db.Contracts.FirstOrDefaultAsync(c => c.Id == edited.Id, ct)
                       ?? throw new BusinessRuleException("The contract could not be found.");

        ValidateBasics(edited);
        await EnsureClientExistsAsync(edited.ClientId, ct);

        if (agreement != null)
        {
            FileValidator.ValidatePdf(agreement.FileName, agreement.Length, agreement.Content);
        }

        if (!ContractWorkflow.CanTransition(existing.Status, edited.Status))
        {
            throw new BusinessRuleException(
                $"A contract cannot move from {existing.Status.ToDisplayName()} to {edited.Status.ToDisplayName()}.");
        }

        if (edited.Status == ContractStatus.Active && existing.Status != ContractStatus.Active)
        {
            if (agreement == null && !existing.HasSignedAgreement)
            {
                throw new BusinessRuleException("A signed agreement (PDF) must be uploaded before a contract can be Active.");
            }

            RequireNotPastEndDate(edited);
        }

        existing.ClientId = edited.ClientId;
        existing.StartDate = edited.StartDate.Date;
        existing.EndDate = edited.EndDate.Date;
        existing.ServiceLevel = edited.ServiceLevel;
        existing.Status = edited.Status;

        StoredFile? stored = null;
        string? oldStoredName = null;
        if (agreement != null)
        {
            stored = await _files.SaveSignedAgreementAsync(agreement.FileName, agreement.Length, agreement.Content, ct);
            oldStoredName = existing.SignedAgreementStoredName;
            ApplyAgreement(existing, stored);
        }

        try
        {
            await _db.SaveChangesAsync(ct);
        }
        catch
        {
            if (stored != null)
            {
                _files.Delete(stored.StoredName);
            }

            throw;
        }

        if (oldStoredName != null)
        {
            _files.Delete(oldStoredName);
        }
    }

    public async Task ChangeStatusAsync(int contractId, ContractStatus newStatus, CancellationToken ct = default)
    {
        var contract = await _db.Contracts.FirstOrDefaultAsync(c => c.Id == contractId, ct)
                       ?? throw new BusinessRuleException("The contract could not be found.");

        if (!ContractWorkflow.CanTransition(contract.Status, newStatus))
        {
            throw new BusinessRuleException(
                $"A contract cannot move from {contract.Status.ToDisplayName()} to {newStatus.ToDisplayName()}.");
        }

        if (newStatus == ContractStatus.Active && contract.Status != ContractStatus.Active)
        {
            if (!contract.HasSignedAgreement)
            {
                throw new BusinessRuleException("Upload the signed agreement (PDF) before activating this contract.");
            }

            RequireNotPastEndDate(contract);
        }

        contract.Status = newStatus;
        await _db.SaveChangesAsync(ct);
    }

    public async Task AttachAgreementAsync(int contractId, AgreementUpload agreement, CancellationToken ct = default)
    {
        var contract = await _db.Contracts.FirstOrDefaultAsync(c => c.Id == contractId, ct)
                       ?? throw new BusinessRuleException("The contract could not be found.");

        FileValidator.ValidatePdf(agreement.FileName, agreement.Length, agreement.Content);

        var stored = await _files.SaveSignedAgreementAsync(agreement.FileName, agreement.Length, agreement.Content, ct);
        var oldStoredName = contract.SignedAgreementStoredName;
        ApplyAgreement(contract, stored);

        try
        {
            await _db.SaveChangesAsync(ct);
        }
        catch
        {
            _files.Delete(stored.StoredName);
            throw;
        }

        if (oldStoredName != null)
        {
            _files.Delete(oldStoredName);
        }
    }

    /// <summary>Automated status tracking: Active contracts whose end date has passed become Expired.</summary>
    public async Task<int> RefreshExpiredContractsAsync(CancellationToken ct = default)
    {
        var today = _time.GetLocalNow().Date;

        var overdue = await _db.Contracts
            .Where(c => c.Status == ContractStatus.Active && c.EndDate < today)
            .ToListAsync(ct);

        foreach (var contract in overdue)
        {
            contract.Status = ContractStatus.Expired;
        }

        if (overdue.Count > 0)
        {
            await _db.SaveChangesAsync(ct);
        }

        return overdue.Count;
    }

    public async Task<List<Contract>> SearchAsync(ContractSearchCriteria criteria, CancellationToken ct = default)
    {
        await RefreshExpiredContractsAsync(ct);

        return await _db.Contracts
            .AsNoTracking()
            .Include(c => c.Client)
            .Include(c => c.ServiceRequests)
            .ApplyFilters(criteria)
            .OrderByDescending(c => c.StartDate)
            .ThenBy(c => c.Id)
            .ToListAsync(ct);
    }

    private void ApplyAgreement(Contract contract, StoredFile stored)
    {
        contract.SignedAgreementStoredName = stored.StoredName;
        contract.SignedAgreementOriginalName = stored.OriginalName;
        contract.SignedAgreementUploadedAt = _time.GetUtcNow().UtcDateTime;
    }

    private static void ValidateBasics(Contract contract)
    {
        if (contract.EndDate.Date <= contract.StartDate.Date)
        {
            throw new BusinessRuleException("The end date must be after the start date.");
        }
    }

    private void RequireNotPastEndDate(Contract contract)
    {
        if (contract.IsPastEndDate(_time.GetLocalNow().Date))
        {
            throw new BusinessRuleException("A contract whose end date has already passed cannot be made Active.");
        }
    }

    private async Task EnsureClientExistsAsync(int clientId, CancellationToken ct)
    {
        if (!await _db.Clients.AnyAsync(c => c.Id == clientId, ct))
        {
            throw new BusinessRuleException("The selected client does not exist.");
        }
    }
}
