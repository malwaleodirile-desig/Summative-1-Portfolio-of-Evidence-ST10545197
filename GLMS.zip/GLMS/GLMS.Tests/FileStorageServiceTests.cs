using System.Text;
using GLMS.Api.Services;

namespace GLMS.Tests;

public class FileStorageServiceTests : IDisposable
{
    private readonly string _dir = Path.Combine(Path.GetTempPath(), "glms-tests-" + Guid.NewGuid().ToString("N"));

    public void Dispose()
    {
        if (Directory.Exists(_dir))
        {
            Directory.Delete(_dir, recursive: true);
        }
    }

    [Fact]
    public async Task SaveSignedAgreement_ValidPdf_WritesFileAndReturnsStoredName()
    {
        var service = new FileStorageService(_dir);
        var bytes = TestData.PdfBytes();
        using var stream = new MemoryStream(bytes);

        var stored = await service.SaveSignedAgreementAsync("agreement.pdf", bytes.Length, stream);

        Assert.EndsWith(".pdf", stored.StoredName);
        Assert.Equal("agreement.pdf", stored.OriginalName);
        Assert.Equal(bytes, await File.ReadAllBytesAsync(Path.Combine(_dir, stored.StoredName)));
    }

    [Fact]
    public async Task SaveSignedAgreement_ExeFile_ThrowsAndWritesNothing()
    {
        var service = new FileStorageService(_dir);
        var bytes = Encoding.ASCII.GetBytes("MZ-binary");
        using var stream = new MemoryStream(bytes);

        await Assert.ThrowsAsync<InvalidFileException>(() =>
            service.SaveSignedAgreementAsync("malware.exe", bytes.Length, stream));

        Assert.Empty(Directory.GetFiles(_dir));
    }

    [Fact]
    public async Task OpenRead_ReturnsSavedContent_AndDeleteRemovesIt()
    {
        var service = new FileStorageService(_dir);
        var bytes = TestData.PdfBytes();
        using var input = new MemoryStream(bytes);
        var stored = await service.SaveSignedAgreementAsync("agreement.pdf", bytes.Length, input);

        using (var read = service.OpenRead(stored.StoredName))
        {
            Assert.NotNull(read);
        }

        service.Delete(stored.StoredName);

        Assert.Null(service.OpenRead(stored.StoredName));
    }

    [Fact]
    public void OpenRead_PathTraversal_DoesNotEscapeStorageFolder()
    {
        var service = new FileStorageService(_dir);
        var outside = Path.Combine(Path.GetTempPath(), "glms-outside-" + Guid.NewGuid().ToString("N") + ".txt");
        File.WriteAllText(outside, "secret");

        try
        {
            var result = service.OpenRead("../" + Path.GetFileName(outside));

            Assert.Null(result);
        }
        finally
        {
            File.Delete(outside);
        }
    }
}
