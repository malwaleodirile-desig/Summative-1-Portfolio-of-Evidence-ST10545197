using System.ComponentModel.DataAnnotations;
using GLMS.Api.Models;

namespace GLMS.Api.Dtos;

// ---------------------------------------------------------------- Auth
public class LoginRequest
{
    [Required]
    public string Username { get; set; } = string.Empty;

    [Required]
    public string Password { get; set; } = string.Empty;
}

public class LoginResponse
{
    public string Token { get; set; } = string.Empty;
    public DateTime ExpiresAtUtc { get; set; }
    public string Username { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
}

public class UserInfoDto
{
    public string Username { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
}

// ---------------------------------------------------------------- Clients
public class ClientRequest
{
    [Required, StringLength(150)]
    public string Name { get; set; } = string.Empty;

    [Required, StringLength(300)]
    public string ContactDetails { get; set; } = string.Empty;

    [Required, StringLength(100)]
    public string Region { get; set; } = string.Empty;
}

public class ClientDto
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string ContactDetails { get; set; } = string.Empty;
    public string Region { get; set; } = string.Empty;
    public int ContractCount { get; set; }
}

// ---------------------------------------------------------------- Contracts
/// <summary>Sent as multipart/form-data so the signed agreement PDF can travel with the contract.</summary>
public class ContractFormRequest
{
    [Required]
    public int? ClientId { get; set; }

    [Required]
    public DateTime? StartDate { get; set; }

    [Required]
    public DateTime? EndDate { get; set; }

    public ContractStatus Status { get; set; } = ContractStatus.Draft;

    public ServiceLevel ServiceLevel { get; set; } = ServiceLevel.Standard;

    /// <summary>Optional PDF. Required before a contract can be Active.</summary>
    public IFormFile? SignedAgreement { get; set; }

    public Contract ToEntity(int id = 0) => new()
    {
        Id = id,
        ClientId = ClientId!.Value,
        StartDate = StartDate!.Value.Date,
        EndDate = EndDate!.Value.Date,
        Status = Status,
        ServiceLevel = ServiceLevel
    };
}

public class UpdateContractStatusRequest
{
    [Required]
    public ContractStatus? Status { get; set; }
}

public class ContractDto
{
    public int Id { get; set; }
    public int ClientId { get; set; }
    public string ClientName { get; set; } = string.Empty;
    public string ClientRegion { get; set; } = string.Empty;
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public ContractStatus Status { get; set; }
    public ServiceLevel ServiceLevel { get; set; }
    public bool HasSignedAgreement { get; set; }
    public string? SignedAgreementFileName { get; set; }
    public DateTime? SignedAgreementUploadedAt { get; set; }
    public int RequestCount { get; set; }
    public bool CanRaiseServiceRequests { get; set; }
    public List<ContractStatus> AllowedNextStatuses { get; set; } = new();
}

// ---------------------------------------------------------------- Service requests
public class CreateServiceRequestRequest
{
    [Required]
    public int? ContractId { get; set; }

    [Required, StringLength(1000)]
    public string Description { get; set; } = string.Empty;

    [Required]
    [Range(typeof(decimal), "0.01", "1000000000", ErrorMessage = "The cost must be greater than zero.")]
    public decimal? CostUsd { get; set; }
}

public class UpdateRequestStatusRequest
{
    [Required]
    public RequestStatus? Status { get; set; }
}

public class ServiceRequestDto
{
    public int Id { get; set; }
    public int ContractId { get; set; }
    public string ClientName { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public decimal CostUsd { get; set; }
    public decimal ExchangeRate { get; set; }
    public decimal CostZar { get; set; }
    public RequestStatus Status { get; set; }
    public List<RequestStatus> AllowedNextStatuses { get; set; } = new();
    public DateTime CreatedAtUtc { get; set; }
}

// ---------------------------------------------------------------- Misc
public class ExchangeRateDto
{
    public string From { get; set; } = "USD";
    public string To { get; set; } = "ZAR";
    public decimal Rate { get; set; }
    public DateTime RetrievedAtUtc { get; set; }
}

public class DashboardDto
{
    public int ClientCount { get; set; }
    public int ContractCount { get; set; }
    public int DraftContracts { get; set; }
    public int ActiveContracts { get; set; }
    public int OnHoldContracts { get; set; }
    public int ExpiredContracts { get; set; }
    public int RequestCount { get; set; }
    public decimal TotalZar { get; set; }
}
