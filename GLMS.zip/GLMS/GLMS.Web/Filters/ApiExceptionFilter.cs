using GLMS.Web.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.ViewFeatures;

namespace GLMS.Web.Filters;

/// <summary>
/// Handles failures when calling the API: expired logins go back to the login page, forbidden calls
/// show an access-denied page, and an unreachable API shows a friendly message.
/// </summary>
public class ApiExceptionFilter : IAsyncExceptionFilter
{
    private readonly ILogger<ApiExceptionFilter> _logger;

    public ApiExceptionFilter(ILogger<ApiExceptionFilter> logger)
    {
        _logger = logger;
    }

    public async Task OnExceptionAsync(ExceptionContext context)
    {
        switch (context.Exception)
        {
            case ApiUnauthorizedException:
                await context.HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
                context.Result = new RedirectToActionResult("Login", "Account", null);
                context.ExceptionHandled = true;
                break;

            case ApiForbiddenException:
                context.Result = new RedirectToActionResult("AccessDenied", "Account", null);
                context.ExceptionHandled = true;
                break;

            case ApiNotFoundException:
                context.Result = new NotFoundResult();
                context.ExceptionHandled = true;
                break;

            case ApiException ex:
                _logger.LogWarning(ex, "The API returned an error.");
                context.Result = ErrorView(context, ex.Message);
                context.ExceptionHandled = true;
                break;

            case HttpRequestException ex:
                _logger.LogError(ex, "The API could not be reached.");
                context.Result = ErrorView(context, "The GLMS API is not reachable right now. Please try again in a moment.");
                context.ExceptionHandled = true;
                break;

            case TaskCanceledException ex when !context.HttpContext.RequestAborted.IsCancellationRequested:
                _logger.LogError(ex, "The API call timed out.");
                context.Result = ErrorView(context, "The GLMS API took too long to respond. Please try again.");
                context.ExceptionHandled = true;
                break;
        }
    }

    private static ViewResult ErrorView(ExceptionContext context, string message)
    {
        var metadata = context.HttpContext.RequestServices.GetRequiredService<IModelMetadataProvider>();
        return new ViewResult
        {
            ViewName = "ApiError",
            ViewData = new ViewDataDictionary<string>(metadata, context.ModelState) { Model = message },
            StatusCode = StatusCodes.Status503ServiceUnavailable
        };
    }
}
