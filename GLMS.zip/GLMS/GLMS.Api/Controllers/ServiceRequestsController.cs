using GLMS.Api.Data;
using GLMS.Api.Dtos;
using GLMS.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GLMS.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ServiceRequestsController : ControllerBase
{
    private readonly GlmsDbContext _db;
    private readonly IServiceRequestService _requests;

    public ServiceRequestsController(GlmsDbContext db, IServiceRequestService requests)
    {
        _db = db;
        _requests = requests;
    }

    /// <summary>List service requests, newest first. Optionally filter by contractId.</summary>
    [HttpGet]
    public async Task<ActionResult<List<ServiceRequestDto>>> GetAll([FromQuery] int? contractId, CancellationToken ct)
    {
        var query = _db.ServiceRequests.AsNoTracking()
            .Include(r => r.Contract).ThenInclude(c => c!.Client)
            .AsQueryable();

        if (contractId.HasValue)
        {
            query = query.Where(r => r.ContractId == contractId.Value);
        }

        var items = await query.OrderByDescending(r => r.CreatedAt).ToListAsync(ct);
        return items.Select(r => r.ToDto()).ToList();
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<ServiceRequestDto>> GetById(int id, CancellationToken ct)
    {
        var request = await _db.ServiceRequests.AsNoTracking()
            .Include(r => r.Contract).ThenInclude(c => c!.Client)
            .FirstOrDefaultAsync(r => r.Id == id, ct);
        return request == null ? NotFound() : request.ToDto();
    }

    /// <summary>
    /// Raise a service request. The contract must be Active. The API fetches the current USD to ZAR
    /// rate, calculates the Rand cost and saves both.
    /// </summary>
    [HttpPost]
    [ProducesResponseType(typeof(ServiceRequestDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
    public async Task<ActionResult<ServiceRequestDto>> Create([FromBody] CreateServiceRequestRequest request,
        CancellationToken ct)
    {
        var created = await _requests.CreateAsync(request.ContractId!.Value, request.Description, request.CostUsd!.Value, ct);

        var saved = await _db.ServiceRequests.AsNoTracking()
            .Include(r => r.Contract).ThenInclude(c => c!.Client)
            .FirstAsync(r => r.Id == created.Id, ct);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, saved.ToDto());
    }

    /// <summary>Move a request through its workflow (Pending, In Progress, Completed, Cancelled).</summary>
    [HttpPatch("{id:int}/status")]
    public async Task<ActionResult<ServiceRequestDto>> UpdateStatus(int id, [FromBody] UpdateRequestStatusRequest request,
        CancellationToken ct)
    {
        if (!await _db.ServiceRequests.AnyAsync(r => r.Id == id, ct))
        {
            return NotFound();
        }

        await _requests.ChangeStatusAsync(id, request.Status!.Value, ct);

        var saved = await _db.ServiceRequests.AsNoTracking()
            .Include(r => r.Contract).ThenInclude(c => c!.Client)
            .FirstAsync(r => r.Id == id, ct);
        return saved.ToDto();
    }
}
