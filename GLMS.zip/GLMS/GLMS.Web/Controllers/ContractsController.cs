using GLMS.Web.Models;
using GLMS.Web.Services;
using GLMS.Web.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GLMS.Web.Controllers;

public class ContractsController : Controller
{
    private readonly IGlmsApiClient _api;

    public ContractsController(IGlmsApiClient api)
    {
        _api = api;
    }

    // GET /Contracts?From=...&To=...&Status=...&ClientName=...
    public async Task<IActionResult> Index(ContractSearchCriteria criteria, CancellationToken ct)
    {
        var vm = new ContractIndexViewModel { Criteria = criteria };

        if (criteria.From.HasValue && criteria.To.HasValue && criteria.From.Value.Date > criteria.To.Value.Date)
        {
            ModelState.AddModelError(string.Empty, "The 'from' date cannot be after the 'to' date.");
            return View(vm);
        }

        vm.Contracts = await _api.SearchContractsAsync(criteria, ct);
        return View(vm);
    }

    public async Task<IActionResult> Details(int id, CancellationToken ct)
    {
        var contract = await _api.GetContractAsync(id, ct);
        if (contract == null)
        {
            return NotFound();
        }

        var requests = await _api.GetServiceRequestsAsync(id, ct);
        return View(new ContractDetailsViewModel { Contract = contract, Requests = requests });
    }

    public async Task<IActionResult> Create(CancellationToken ct)
    {
        var today = DateTime.Today;
        var vm = new ContractFormViewModel { StartDate = today, EndDate = today.AddYears(1) };
        await LoadClientsAsync(vm, ct);
        return View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(ContractFormViewModel vm, CancellationToken ct)
    {
        if (ModelState.IsValid)
        {
            try
            {
                var created = await _api.CreateContractAsync(vm.ToSubmission(), ct);
                TempData["Success"] = $"Contract #{created.Id} was created.";
                return RedirectToAction(nameof(Details), new { id = created.Id });
            }
            catch (ApiValidationException ex)
            {
                ModelState.AddModelError(string.Empty, ex.Message);
            }
        }

        await LoadClientsAsync(vm, ct);
        return View(vm);
    }

    public async Task<IActionResult> Edit(int id, CancellationToken ct)
    {
        var contract = await _api.GetContractAsync(id, ct);
        if (contract == null)
        {
            return NotFound();
        }

        var vm = new ContractFormViewModel
        {
            Id = contract.Id,
            ClientId = contract.ClientId,
            StartDate = contract.StartDate,
            EndDate = contract.EndDate,
            Status = contract.Status,
            ServiceLevel = contract.ServiceLevel,
            ExistingAgreementName = contract.SignedAgreementFileName
        };
        await LoadClientsAsync(vm, ct);
        return View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, ContractFormViewModel vm, CancellationToken ct)
    {
        if (id != vm.Id)
        {
            return NotFound();
        }

        if (ModelState.IsValid)
        {
            try
            {
                await _api.UpdateContractAsync(id, vm.ToSubmission(), ct);
                TempData["Success"] = $"Contract #{id} was updated.";
                return RedirectToAction(nameof(Details), new { id });
            }
            catch (ApiValidationException ex)
            {
                ModelState.AddModelError(string.Empty, ex.Message);
            }
        }

        var existing = await _api.GetContractAsync(id, ct);
        vm.ExistingAgreementName = existing?.SignedAgreementFileName;
        await LoadClientsAsync(vm, ct);
        return View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> ChangeStatus(int id, ContractStatus newStatus, CancellationToken ct)
    {
        try
        {
            await _api.ChangeContractStatusAsync(id, newStatus, ct);
            TempData["Success"] = $"Contract #{id} is now {newStatus}.";
        }
        catch (ApiValidationException ex)
        {
            TempData["Error"] = ex.Message;
        }

        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> UploadAgreement(int id, IFormFile? signedAgreement, CancellationToken ct)
    {
        if (signedAgreement == null || string.IsNullOrEmpty(signedAgreement.FileName))
        {
            TempData["Error"] = "No file was selected.";
            return RedirectToAction(nameof(Details), new { id });
        }

        try
        {
            await _api.UploadAgreementAsync(id, signedAgreement, ct);
            TempData["Success"] = "The signed agreement was uploaded.";
        }
        catch (ApiValidationException ex)
        {
            TempData["Error"] = ex.Message;
        }

        return RedirectToAction(nameof(Details), new { id });
    }

    public async Task<IActionResult> DownloadAgreement(int id, CancellationToken ct)
    {
        var bytes = await _api.DownloadAgreementAsync(id, ct);
        return bytes == null ? NotFound() : File(bytes, "application/pdf");
    }

    private async Task LoadClientsAsync(ContractFormViewModel vm, CancellationToken ct)
    {
        var clients = await _api.GetClientsAsync(ct);
        vm.Clients = clients.Select(c => new SelectListItem
        {
            Value = c.Id.ToString(),
            Text = $"{c.Name} ({c.Region})",
            Selected = vm.ClientId == c.Id
        }).ToList();
    }
}
