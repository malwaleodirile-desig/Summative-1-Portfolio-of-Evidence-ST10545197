using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace GLMS.Api.Models;

public class ServiceRequest
{
    public int Id { get; set; }

    public int ContractId { get; set; }

    [ValidateNever]
    public Contract? Contract { get; set; }

    [Required, StringLength(1000)]
    public string Description { get; set; } = string.Empty;

    /// <summary>The amount the user typed, in US dollars.</summary>
    [Display(Name = "Cost (USD)")]
    public decimal CostUsd { get; set; }

    /// <summary>USD to ZAR rate used when the request was saved.</summary>
    [Display(Name = "Exchange rate")]
    public decimal ExchangeRate { get; set; }

    /// <summary>Calculated local cost in South African Rand.</summary>
    [Display(Name = "Cost (ZAR)")]
    public decimal CostZar { get; set; }

    public RequestStatus Status { get; set; } = RequestStatus.Pending;

    [Display(Name = "Created")]
    public DateTime CreatedAt { get; set; }
}
