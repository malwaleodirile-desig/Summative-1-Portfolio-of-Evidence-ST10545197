using System.ComponentModel.DataAnnotations;

namespace GLMS.Api.Models;

/// <summary>A person who can sign in to the system. Roles: Admin or Manager.</summary>
public class AppUser
{
    public int Id { get; set; }

    [Required, StringLength(100)]
    public string Username { get; set; } = string.Empty;

    [Required, StringLength(500)]
    public string PasswordHash { get; set; } = string.Empty;

    [Required, StringLength(50)]
    public string Role { get; set; } = Roles.Manager;
}

public static class Roles
{
    public const string Admin = "Admin";
    public const string Manager = "Manager";
}
