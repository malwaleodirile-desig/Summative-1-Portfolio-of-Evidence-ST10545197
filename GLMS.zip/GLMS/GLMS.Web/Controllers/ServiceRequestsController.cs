using GLMS.Web.Helpers;
using GLMS.Web.Models;
using GLMS.Web.Services;
using GLMS.Web.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GLMS.Web.Controllers;

public class ServiceRequestsController : Controller
{
    private readonly IGlmsApiClient _api;

    public ServiceRequestsController(IGlmsApiClient api)
    {
        _api = api;
    }

    public async Task<IActionResult> Index(CancellationToken ct) => View(await _api.GetServiceRequestsAsync(null, ct));

    public async Task<IActionResult> Create(int? contractId, CancellationToken ct)
    {
        var vm = new ServiceRequestCreateViewModel { ContractId = contractId };
        await PopulateAsync(vm, ct);
        return View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(ServiceRequestCreateViewModel vm, CancellationToken ct)
    {
        if (ModelState.IsValid)
        {
            try
            {
                var created = await _api.CreateServiceRequestAsync(vm.ContractId!.Value, vm.Description, vm.CostUsd!.Value, ct);
                TempData["Success"] =
                    $"Service request #{created.Id} was saved: {created.CostUsd.ToUsd()} at a rate of " +
                    $"{created.ExchangeRate.ToString("0.0000", System.Globalization.CultureInfo.InvariantCulture)} = {created.CostZar.ToZar()}.";
                return RedirectToAction(nameof(Index));
            }
            catch (ApiValidationException ex)
            {
                ModelState.AddModelError(string.Empty, ex.Message);
            }
            catch (ApiException ex) when (ex.StatusCode == 503)
            {
                ModelState.AddModelError(string.Empty,
                    "The exchange rate service is unavailable right now, so the request was not saved. Please try again shortly.");
            }
        }

        await PopulateAsync(vm, ct);
        return View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> ChangeStatus(int id, RequestStatus newStatus, CancellationToken ct)
    {
        try
        {
            await _api.ChangeRequestStatusAsync(id, newStatus, ct);
            TempData["Success"] = $"Service request #{id} is now {newStatus.ToDisplayName()}.";
        }
        catch (ApiValidationException ex)
        {
            TempData["Error"] = ex.Message;
        }

        return RedirectToAction(nameof(Index));
    }

    private async Task PopulateAsync(ServiceRequestCreateViewModel vm, CancellationToken ct)
    {
        var contracts = await _api.SearchContractsAsync(new ContractSearchCriteria(), ct);

        vm.Contracts = contracts
            .OrderBy(c => c.ClientName).ThenBy(c => c.Id)
            .Select(c => new SelectListItem
            {
                Value = c.Id.ToString(),
                Text = $"#{c.Id} - {c.ClientName} ({c.Status.ToDisplayName()}, ends {c.EndDate:yyyy-MM-dd})",
                Selected = vm.ContractId == c.Id
            }).ToList();

        try
        {
            vm.ExchangeRate = (await _api.GetUsdToZarRateAsync(ct)).Rate;
            vm.RateError = null;
        }
        catch (ApiException ex) when (ex.StatusCode == 503)
        {
            vm.ExchangeRate = null;
            vm.RateError = "The exchange rate service is unavailable. The live preview is off; the rate is fetched again when you save.";
        }
    }
}
