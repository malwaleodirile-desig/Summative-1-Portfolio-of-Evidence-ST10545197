using System.Net.Http.Headers;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;

namespace GLMS.Web.Services;

/// <summary>
/// Adds the signed-in user's JWT (kept inside the encrypted login cookie) to every call the MVC app
/// makes to the API.
/// </summary>
public class AuthTokenHandler : DelegatingHandler
{
    public const string TokenName = "access_token";

    private readonly IHttpContextAccessor _accessor;

    public AuthTokenHandler(IHttpContextAccessor accessor)
    {
        _accessor = accessor;
    }

    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        var context = _accessor.HttpContext;
        if (context != null)
        {
            var token = await context.GetTokenAsync(CookieAuthenticationDefaults.AuthenticationScheme, TokenName);
            if (!string.IsNullOrEmpty(token))
            {
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            }
        }

        return await base.SendAsync(request, cancellationToken);
    }
}
