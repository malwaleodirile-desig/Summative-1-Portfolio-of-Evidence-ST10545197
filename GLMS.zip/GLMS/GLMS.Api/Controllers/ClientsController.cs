using GLMS.Api.Data;
using GLMS.Api.Dtos;
using GLMS.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GLMS.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ClientsController : ControllerBase
{
    private readonly GlmsDbContext _db;

    public ClientsController(GlmsDbContext db)
    {
        _db = db;
    }

    /// <summary>List all clients.</summary>
    [HttpGet]
    public async Task<ActionResult<List<ClientDto>>> GetAll(CancellationToken ct)
    {
        var clients = await _db.Clients.AsNoTracking()
            .Include(c => c.Contracts)
            .OrderBy(c => c.Name)
            .ToListAsync(ct);
        return clients.Select(c => c.ToDto()).ToList();
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<ClientDto>> GetById(int id, CancellationToken ct)
    {
        var client = await _db.Clients.AsNoTracking().Include(c => c.Contracts)
            .FirstOrDefaultAsync(c => c.Id == id, ct);
        return client == null ? NotFound() : client.ToDto();
    }

    [HttpPost]
    [ProducesResponseType(typeof(ClientDto), StatusCodes.Status201Created)]
    public async Task<ActionResult<ClientDto>> Create([FromBody] ClientRequest request, CancellationToken ct)
    {
        var client = new Client
        {
            Name = request.Name.Trim(),
            ContactDetails = request.ContactDetails.Trim(),
            Region = request.Region.Trim()
        };
        _db.Clients.Add(client);
        await _db.SaveChangesAsync(ct);
        return CreatedAtAction(nameof(GetById), new { id = client.Id }, client.ToDto());
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<ClientDto>> Update(int id, [FromBody] ClientRequest request, CancellationToken ct)
    {
        var client = await _db.Clients.Include(c => c.Contracts).FirstOrDefaultAsync(c => c.Id == id, ct);
        if (client == null)
        {
            return NotFound();
        }

        client.Name = request.Name.Trim();
        client.ContactDetails = request.ContactDetails.Trim();
        client.Region = request.Region.Trim();
        await _db.SaveChangesAsync(ct);
        return client.ToDto();
    }

    /// <summary>Delete a client (Admin only). Clients that still have contracts cannot be deleted.</summary>
    [HttpDelete("{id:int}")]
    [Authorize(Roles = Roles.Admin)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> Delete(int id, CancellationToken ct)
    {
        var client = await _db.Clients.FirstOrDefaultAsync(c => c.Id == id, ct);
        if (client == null)
        {
            return NotFound();
        }

        if (await _db.Contracts.AnyAsync(c => c.ClientId == id, ct))
        {
            return BadRequest(new ProblemDetails
            {
                Status = StatusCodes.Status400BadRequest,
                Title = "A business rule was not met",
                Detail = "This client still has contracts and cannot be deleted."
            });
        }

        _db.Clients.Remove(client);
        await _db.SaveChangesAsync(ct);
        return NoContent();
    }
}
