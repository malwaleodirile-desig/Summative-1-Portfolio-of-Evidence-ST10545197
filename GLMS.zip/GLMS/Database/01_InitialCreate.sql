-- GLMS database migration script: InitialCreate (owned by GLMS.Api)
-- Equivalent to the EF Core migration 20261014120000_InitialCreate.
-- You can regenerate it with:
--   dotnet ef migrations script --project GLMS.Api --output Database/01_InitialCreate.sql
-- Run it against an empty database named GLMS (SSMS, Azure Data Studio or sqlcmd).
-- Note: the API also applies the migration automatically when it starts, so this script is only
-- needed if you want to create the schema by hand.

IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO

BEGIN TRANSACTION;
GO

CREATE TABLE [AppUsers] (
    [Id] int NOT NULL IDENTITY,
    [Username] nvarchar(100) NOT NULL,
    [PasswordHash] nvarchar(500) NOT NULL,
    [Role] nvarchar(50) NOT NULL,
    CONSTRAINT [PK_AppUsers] PRIMARY KEY ([Id])
);
GO

CREATE TABLE [Clients] (
    [Id] int NOT NULL IDENTITY,
    [Name] nvarchar(150) NOT NULL,
    [ContactDetails] nvarchar(300) NOT NULL,
    [Region] nvarchar(100) NOT NULL,
    CONSTRAINT [PK_Clients] PRIMARY KEY ([Id])
);
GO

CREATE TABLE [Contracts] (
    [Id] int NOT NULL IDENTITY,
    [ClientId] int NOT NULL,
    [StartDate] datetime2 NOT NULL,
    [EndDate] datetime2 NOT NULL,
    [Status] int NOT NULL,
    [ServiceLevel] int NOT NULL,
    [SignedAgreementOriginalName] nvarchar(260) NULL,
    [SignedAgreementStoredName] nvarchar(100) NULL,
    [SignedAgreementUploadedAt] datetime2 NULL,
    CONSTRAINT [PK_Contracts] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_Contracts_Clients_ClientId] FOREIGN KEY ([ClientId]) REFERENCES [Clients] ([Id])
);
GO

CREATE TABLE [ServiceRequests] (
    [Id] int NOT NULL IDENTITY,
    [ContractId] int NOT NULL,
    [Description] nvarchar(1000) NOT NULL,
    [CostUsd] decimal(18,2) NOT NULL,
    [ExchangeRate] decimal(18,6) NOT NULL,
    [CostZar] decimal(18,2) NOT NULL,
    [Status] int NOT NULL,
    [CreatedAt] datetime2 NOT NULL,
    CONSTRAINT [PK_ServiceRequests] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_ServiceRequests_Contracts_ContractId] FOREIGN KEY ([ContractId]) REFERENCES [Contracts] ([Id])
);
GO

CREATE UNIQUE INDEX [IX_AppUsers_Username] ON [AppUsers] ([Username]);
GO

CREATE INDEX [IX_Contracts_ClientId] ON [Contracts] ([ClientId]);
GO

CREATE INDEX [IX_Contracts_Status_EndDate] ON [Contracts] ([Status], [EndDate]);
GO

CREATE INDEX [IX_ServiceRequests_ContractId] ON [ServiceRequests] ([ContractId]);
GO

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20261014120000_InitialCreate', N'8.0.10');
GO

COMMIT;
GO
