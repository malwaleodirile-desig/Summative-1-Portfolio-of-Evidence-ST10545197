using GLMS.Api.Models;
using GLMS.Api.Services;

namespace GLMS.Tests;

public class ContractSearchTests
{
    private static readonly Client Atlas = new() { Id = 1, Name = "Atlas Freight", ContactDetails = "x", Region = "Europe" };
    private static readonly Client Cape = new() { Id = 2, Name = "Cape Harbour", ContactDetails = "x", Region = "Africa" };

    private static readonly List<Contract> Contracts = new()
    {
        new Contract { Id = 1, Client = Atlas, Status = ContractStatus.Active, StartDate = new DateTime(2026, 1, 1), EndDate = new DateTime(2026, 12, 31) },
        new Contract { Id = 2, Client = Atlas, Status = ContractStatus.Expired, StartDate = new DateTime(2025, 1, 1), EndDate = new DateTime(2025, 12, 31) },
        new Contract { Id = 3, Client = Cape, Status = ContractStatus.OnHold, StartDate = new DateTime(2026, 3, 1), EndDate = new DateTime(2026, 9, 30) },
        new Contract { Id = 4, Client = Cape, Status = ContractStatus.Draft, StartDate = new DateTime(2027, 1, 1), EndDate = new DateTime(2027, 12, 31) }
    };

    private static List<int> Search(ContractSearchCriteria criteria) =>
        Contracts.AsQueryable().ApplyFilters(criteria).OrderBy(c => c.Id).Select(c => c.Id).ToList();

    [Fact]
    public void NoFilters_ReturnsEverything()
    {
        Assert.Equal(new[] { 1, 2, 3, 4 }, Search(new ContractSearchCriteria()));
    }

    [Theory]
    [InlineData(ContractStatus.Active, 1)]
    [InlineData(ContractStatus.Expired, 2)]
    [InlineData(ContractStatus.OnHold, 3)]
    [InlineData(ContractStatus.Draft, 4)]
    public void StatusFilter_ReturnsOnlyThatStatus(ContractStatus status, int expectedId)
    {
        Assert.Equal(new[] { expectedId }, Search(new ContractSearchCriteria { Status = status }));
    }

    [Fact]
    public void DateRange_ReturnsContractsOverlappingTheRange()
    {
        var result = Search(new ContractSearchCriteria { From = new DateTime(2026, 6, 1), To = new DateTime(2026, 6, 30) });

        Assert.Equal(new[] { 1, 3 }, result);
    }

    [Fact]
    public void DateRange_InThePast_FindsExpiredContract()
    {
        var result = Search(new ContractSearchCriteria { From = new DateTime(2025, 6, 1), To = new DateTime(2025, 6, 30) });

        Assert.Equal(new[] { 2 }, result);
    }

    [Fact]
    public void DateRange_BoundariesAreInclusive()
    {
        var result = Search(new ContractSearchCriteria { From = new DateTime(2026, 12, 31), To = new DateTime(2026, 12, 31) });

        Assert.Equal(new[] { 1 }, result);
    }

    [Fact]
    public void OnlyFromDate_ReturnsContractsEndingOnOrAfterIt()
    {
        Assert.Equal(new[] { 4 }, Search(new ContractSearchCriteria { From = new DateTime(2027, 6, 1) }));
    }

    [Fact]
    public void OnlyToDate_ReturnsContractsStartingOnOrBeforeIt()
    {
        Assert.Equal(new[] { 2 }, Search(new ContractSearchCriteria { To = new DateTime(2025, 3, 1) }));
    }

    [Fact]
    public void DateRangeAndStatus_AreCombined()
    {
        var result = Search(new ContractSearchCriteria
        {
            From = new DateTime(2026, 6, 1),
            To = new DateTime(2026, 6, 30),
            Status = ContractStatus.Active
        });

        Assert.Equal(new[] { 1 }, result);
    }

    [Fact]
    public void ClientNameFilter_MatchesPartOfName()
    {
        Assert.Equal(new[] { 3, 4 }, Search(new ContractSearchCriteria { ClientName = "Harbour" }));
    }

    [Fact]
    public void ClientIdFilter_ReturnsOnlyThatClientsContracts()
    {
        Assert.Equal(new[] { 1, 2 }, Search(new ContractSearchCriteria { ClientId = 1 }));
    }

    [Fact]
    public void NoMatches_ReturnsEmptyList()
    {
        var result = Search(new ContractSearchCriteria { Status = ContractStatus.Active, To = new DateTime(2020, 1, 1) });

        Assert.Empty(result);
    }
}
