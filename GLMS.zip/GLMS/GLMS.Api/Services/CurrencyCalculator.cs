namespace GLMS.Api.Services;

/// <summary>Pure currency maths, kept free of any I/O so it is easy to unit test.</summary>
public static class CurrencyCalculator
{
    /// <summary>Converts a US dollar amount to South African Rand, rounded to 2 decimals (half away from zero).</summary>
    public static decimal ConvertUsdToZar(decimal usdAmount, decimal rate)
    {
        if (usdAmount < 0)
        {
            throw new ArgumentOutOfRangeException(nameof(usdAmount), "The amount cannot be negative.");
        }

        if (rate <= 0)
        {
            throw new ArgumentOutOfRangeException(nameof(rate), "The exchange rate must be greater than zero.");
        }

        return Math.Round(usdAmount * rate, 2, MidpointRounding.AwayFromZero);
    }
}
