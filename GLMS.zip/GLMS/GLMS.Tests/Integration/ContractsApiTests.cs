using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using GLMS.Api.Dtos;
using GLMS.Api.Models;

namespace GLMS.Tests.Integration;

/// <summary>Calls the contract endpoints and asserts on status codes and the returned JSON.</summary>
public class ContractsApiTests : IClassFixture<GlmsApiFactory>
{
    private readonly GlmsApiFactory _factory;

    public ContractsApiTests(GlmsApiFactory factory)
    {
        _factory = factory;
    }

    [Fact]
    public async Task GetContracts_Returns200_WithJsonList()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);

        var response = await client.GetAsync("/api/contracts");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        Assert.Equal("application/json", response.Content.Headers.ContentType?.MediaType);

        var contracts = await response.Content.ReadFromJsonAsync<List<ContractDto>>(ApiTestHelpers.Json);
        Assert.NotNull(contracts);
        Assert.True(contracts!.Count >= 5);
        Assert.All(contracts, c =>
        {
            Assert.True(c.Id > 0);
            Assert.False(string.IsNullOrWhiteSpace(c.ClientName));
        });
    }

    [Theory]
    [InlineData(ContractStatus.Active)]
    [InlineData(ContractStatus.Draft)]
    [InlineData(ContractStatus.OnHold)]
    [InlineData(ContractStatus.Expired)]
    public async Task GetContracts_FilteredByStatus_ReturnsOnlyThatStatus(ContractStatus status)
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);

        var contracts = await ApiTestHelpers.GetContractsAsync(client, $"?status={status}");

        Assert.NotEmpty(contracts);
        Assert.All(contracts, c => Assert.Equal(status, c.Status));
    }

    [Fact]
    public async Task GetContracts_FilteredByDateRange_ReturnsOverlappingContracts()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);
        var today = DateTime.Today.ToString("yyyy-MM-dd");

        var contracts = await ApiTestHelpers.GetContractsAsync(client, $"?from={today}&to={today}");

        Assert.Contains(contracts, c => c.Status == ContractStatus.Active);
        Assert.All(contracts, c =>
        {
            Assert.True(c.StartDate.Date <= DateTime.Today);
            Assert.True(c.EndDate.Date >= DateTime.Today);
        });
    }

    [Fact]
    public async Task GetContracts_DateRangeInTheDistantPast_ReturnsNothing()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);

        var contracts = await ApiTestHelpers.GetContractsAsync(client, "?from=2000-01-01&to=2000-12-31");

        Assert.Empty(contracts);
    }

    [Fact]
    public async Task GetContracts_DateRangeAndStatusCombined()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);
        var today = DateTime.Today.ToString("yyyy-MM-dd");

        var contracts = await ApiTestHelpers.GetContractsAsync(client, $"?from={today}&to={today}&status=Active");

        Assert.NotEmpty(contracts);
        Assert.All(contracts, c => Assert.Equal(ContractStatus.Active, c.Status));
    }

    [Fact]
    public async Task GetContracts_FromAfterTo_Returns400()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);

        var response = await client.GetAsync("/api/contracts?from=2026-12-31&to=2026-01-01");

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task GetContracts_UnknownStatus_Returns400()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);

        var response = await client.GetAsync("/api/contracts?status=Banana");

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task GetContractById_Existing_Returns200()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);
        var existing = await ApiTestHelpers.FindContractAsync(client, ContractStatus.Active);

        var response = await client.GetAsync($"/api/contracts/{existing.Id}");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var dto = await ApiTestHelpers.ReadAsync<ContractDto>(response);
        Assert.Equal(existing.Id, dto.Id);
        Assert.True(dto.CanRaiseServiceRequests);
    }

    [Fact]
    public async Task GetContractById_Missing_Returns404()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);

        var response = await client.GetAsync("/api/contracts/999999");

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task PostContract_DraftWithPdf_Returns201_AndCanBeFetched()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);
        var clientId = await ApiTestHelpers.FirstClientIdAsync(client);

        var response = await client.PostAsync("/api/contracts", ApiTestHelpers.ContractForm(clientId));

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        Assert.NotNull(response.Headers.Location);
        var created = await ApiTestHelpers.ReadAsync<ContractDto>(response);
        Assert.Equal(ContractStatus.Draft, created.Status);
        Assert.True(created.HasSignedAgreement);
        Assert.Equal("agreement.pdf", created.SignedAgreementFileName);

        var fetched = await client.GetAsync($"/api/contracts/{created.Id}");
        Assert.Equal(HttpStatusCode.OK, fetched.StatusCode);
    }

    [Fact]
    public async Task PostContract_WithExeFile_Returns400_AndMentionsPdf()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);
        var clientId = await ApiTestHelpers.FirstClientIdAsync(client);
        var form = ApiTestHelpers.ContractForm(clientId, fileName: "malware.exe", fileBytes: Encoding.ASCII.GetBytes("MZ-binary"));

        var response = await client.PostAsync("/api/contracts", form);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        Assert.Contains("PDF", await response.Content.ReadAsStringAsync());
    }

    [Fact]
    public async Task PostContract_ExeRenamedToPdf_Returns400()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);
        var clientId = await ApiTestHelpers.FirstClientIdAsync(client);
        var form = ApiTestHelpers.ContractForm(clientId, fileName: "fake.pdf", fileBytes: Encoding.ASCII.GetBytes("MZ-binary"));

        var response = await client.PostAsync("/api/contracts", form);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task PostContract_EndDateBeforeStartDate_Returns400()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);
        var clientId = await ApiTestHelpers.FirstClientIdAsync(client);
        var form = ApiTestHelpers.ContractForm(clientId, start: DateTime.Today, end: DateTime.Today.AddDays(-5));

        var response = await client.PostAsync("/api/contracts", form);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task PostContract_MissingRequiredFields_Returns400()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);

        var response = await client.PostAsync("/api/contracts", new MultipartFormDataContent { { new StringContent("Draft"), "Status" } });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task PostContract_ActiveAsManager_IsForbidden()
    {
        var manager = await ApiTestHelpers.ManagerAsync(_factory);
        var clientId = await ApiTestHelpers.FirstClientIdAsync(manager);

        var response = await manager.PostAsync("/api/contracts", ApiTestHelpers.ContractForm(clientId, status: "Active"));

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task PostContract_ActiveAsAdminWithoutPdf_Returns400()
    {
        var admin = await ApiTestHelpers.AdminAsync(_factory);
        var clientId = await ApiTestHelpers.FirstClientIdAsync(admin);

        var response = await admin.PostAsync("/api/contracts", ApiTestHelpers.ContractForm(clientId, status: "Active", fileName: null));

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task PostContract_ActiveAsAdminWithPdf_Returns201()
    {
        var admin = await ApiTestHelpers.AdminAsync(_factory);
        var clientId = await ApiTestHelpers.FirstClientIdAsync(admin);

        var response = await admin.PostAsync("/api/contracts", ApiTestHelpers.ContractForm(clientId, status: "Active"));

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        Assert.Equal(ContractStatus.Active, (await ApiTestHelpers.ReadAsync<ContractDto>(response)).Status);
    }

    [Fact]
    public async Task PatchStatus_AdminApprovesDraft_Returns200_AndContractIsActive()
    {
        var admin = await ApiTestHelpers.AdminAsync(_factory);
        var clientId = await ApiTestHelpers.FirstClientIdAsync(admin);
        var created = await ApiTestHelpers.ReadAsync<ContractDto>(
            await admin.PostAsync("/api/contracts", ApiTestHelpers.ContractForm(clientId)));

        var response = await ApiTestHelpers.PatchAsync(admin, $"/api/contracts/{created.Id}/status", new { status = "Active" });

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var updated = await ApiTestHelpers.ReadAsync<ContractDto>(response);
        Assert.Equal(ContractStatus.Active, updated.Status);
        Assert.True(updated.CanRaiseServiceRequests);
    }

    [Fact]
    public async Task PatchStatus_AsManager_Returns403()
    {
        var manager = await ApiTestHelpers.ManagerAsync(_factory);
        var draft = await ApiTestHelpers.FindContractAsync(manager, ContractStatus.Draft);

        var response = await ApiTestHelpers.PatchAsync(manager, $"/api/contracts/{draft.Id}/status", new { status = "Active" });

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task PatchStatus_DraftWithoutAgreement_Returns400()
    {
        var admin = await ApiTestHelpers.AdminAsync(_factory);
        var clientId = await ApiTestHelpers.FirstClientIdAsync(admin);
        var created = await ApiTestHelpers.ReadAsync<ContractDto>(
            await admin.PostAsync("/api/contracts", ApiTestHelpers.ContractForm(clientId, fileName: null)));

        var response = await ApiTestHelpers.PatchAsync(admin, $"/api/contracts/{created.Id}/status", new { status = "Active" });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task PatchStatus_ExpiredToActive_Returns400()
    {
        var admin = await ApiTestHelpers.AdminAsync(_factory);
        var expired = await ApiTestHelpers.FindContractAsync(admin, ContractStatus.Expired);

        var response = await ApiTestHelpers.PatchAsync(admin, $"/api/contracts/{expired.Id}/status", new { status = "Active" });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task PatchStatus_UnknownContract_Returns404()
    {
        var admin = await ApiTestHelpers.AdminAsync(_factory);

        var response = await ApiTestHelpers.PatchAsync(admin, "/api/contracts/999999/status", new { status = "Active" });

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task PatchStatus_WithoutToken_Returns401()
    {
        var response = await ApiTestHelpers.PatchAsync(_factory.CreateClient(), "/api/contracts/1/status", new { status = "Active" });

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task PutContract_ManagerChangingStatus_Returns403()
    {
        var manager = await ApiTestHelpers.ManagerAsync(_factory);
        var active = await ApiTestHelpers.FindContractAsync(manager, ContractStatus.Active);

        var form = ApiTestHelpers.ContractForm(active.ClientId, status: "OnHold", fileName: null,
            start: active.StartDate, end: active.EndDate);
        var response = await manager.PutAsync($"/api/contracts/{active.Id}", form);

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task PutContract_ManagerEditingDates_Returns200()
    {
        var manager = await ApiTestHelpers.ManagerAsync(_factory);
        var clientId = await ApiTestHelpers.FirstClientIdAsync(manager);
        var created = await ApiTestHelpers.ReadAsync<ContractDto>(
            await manager.PostAsync("/api/contracts", ApiTestHelpers.ContractForm(clientId)));

        var newEnd = DateTime.Today.AddYears(2);
        var form = ApiTestHelpers.ContractForm(clientId, status: "Draft", fileName: null, end: newEnd);
        var response = await manager.PutAsync($"/api/contracts/{created.Id}", form);

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        Assert.Equal(newEnd.Date, (await ApiTestHelpers.ReadAsync<ContractDto>(response)).EndDate.Date);
    }

    [Fact]
    public async Task Agreement_Download_ReturnsPdfBytes()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);
        var active = await ApiTestHelpers.FindContractAsync(client, ContractStatus.Active);

        var response = await client.GetAsync($"/api/contracts/{active.Id}/agreement");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        Assert.Equal("application/pdf", response.Content.Headers.ContentType?.MediaType);
        var bytes = await response.Content.ReadAsByteArrayAsync();
        Assert.StartsWith("%PDF-", Encoding.ASCII.GetString(bytes, 0, 5));
    }

    [Fact]
    public async Task Agreement_Download_WhenNoneUploaded_Returns404()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);
        var draft = (await ApiTestHelpers.GetContractsAsync(client, "?status=Draft")).First(c => !c.HasSignedAgreement);

        var response = await client.GetAsync($"/api/contracts/{draft.Id}/agreement");

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Agreement_Upload_Pdf_AttachesFileToContract()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);
        var clientId = await ApiTestHelpers.FirstClientIdAsync(client);
        var created = await ApiTestHelpers.ReadAsync<ContractDto>(
            await client.PostAsync("/api/contracts", ApiTestHelpers.ContractForm(clientId, fileName: null)));
        Assert.False(created.HasSignedAgreement);

        var form = new MultipartFormDataContent();
        var file = new ByteArrayContent(TestData.PdfBytes());
        file.Headers.ContentType = new MediaTypeHeaderValue("application/pdf");
        form.Add(file, "file", "signed.pdf");
        var response = await client.PostAsync($"/api/contracts/{created.Id}/agreement", form);

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var updated = await ApiTestHelpers.ReadAsync<ContractDto>(response);
        Assert.True(updated.HasSignedAgreement);
        Assert.Equal("signed.pdf", updated.SignedAgreementFileName);
    }

    [Fact]
    public async Task Agreement_Upload_ExeFile_Returns400()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);
        var active = await ApiTestHelpers.FindContractAsync(client, ContractStatus.Active);

        var form = new MultipartFormDataContent();
        form.Add(new ByteArrayContent(Encoding.ASCII.GetBytes("MZ-binary")), "file", "setup.exe");
        var response = await client.PostAsync($"/api/contracts/{active.Id}/agreement", form);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }
}
