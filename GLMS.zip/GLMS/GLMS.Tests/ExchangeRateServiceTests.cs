using System.Net;
using System.Text;
using GLMS.Api.Services;

namespace GLMS.Tests;

public class ExchangeRateServiceTests
{
    private class StubHandler : HttpMessageHandler
    {
        private readonly Func<HttpRequestMessage, HttpResponseMessage> _responder;
        public HttpRequestMessage? LastRequest { get; private set; }

        public StubHandler(Func<HttpRequestMessage, HttpResponseMessage> responder) => _responder = responder;

        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
        {
            LastRequest = request;
            return Task.FromResult(_responder(request));
        }
    }

    private static HttpResponseMessage Json(string body, HttpStatusCode status = HttpStatusCode.OK) =>
        new(status) { Content = new StringContent(body, Encoding.UTF8, "application/json") };

    private static ExchangeRateService CreateService(StubHandler handler) =>
        new(new HttpClient(handler) { BaseAddress = new Uri("https://rates.example.test/") });

    [Fact]
    public async Task GetUsdToZarRate_SuccessfulResponse_ReturnsZarRate()
    {
        var handler = new StubHandler(_ => Json("{\"result\":\"success\",\"base_code\":\"USD\",\"rates\":{\"USD\":1,\"EUR\":0.92,\"ZAR\":18.4567}}"));

        var rate = await CreateService(handler).GetUsdToZarRateAsync();

        Assert.Equal(18.4567m, rate);
        Assert.Equal("https://rates.example.test/" + ExchangeRateService.RatesPath, handler.LastRequest!.RequestUri!.ToString());
    }

    [Fact]
    public async Task GetUsdToZarRate_ServerError_ThrowsExchangeRateUnavailable()
    {
        var handler = new StubHandler(_ => Json("{}", HttpStatusCode.InternalServerError));

        await Assert.ThrowsAsync<ExchangeRateUnavailableException>(() => CreateService(handler).GetUsdToZarRateAsync());
    }

    [Fact]
    public async Task GetUsdToZarRate_NetworkFailure_ThrowsExchangeRateUnavailable()
    {
        var handler = new StubHandler(_ => throw new HttpRequestException("offline"));

        await Assert.ThrowsAsync<ExchangeRateUnavailableException>(() => CreateService(handler).GetUsdToZarRateAsync());
    }

    [Fact]
    public async Task GetUsdToZarRate_InvalidJson_ThrowsExchangeRateUnavailable()
    {
        var handler = new StubHandler(_ => Json("this is not json"));

        await Assert.ThrowsAsync<ExchangeRateUnavailableException>(() => CreateService(handler).GetUsdToZarRateAsync());
    }

    [Theory]
    [InlineData("{\"result\":\"error\",\"error-type\":\"quota-reached\"}")]
    [InlineData("{\"result\":\"success\",\"rates\":{\"EUR\":0.92}}")]
    [InlineData("{\"result\":\"success\",\"rates\":{\"ZAR\":0}}")]
    [InlineData("{\"result\":\"success\",\"rates\":{\"ZAR\":\"abc\"}}")]
    [InlineData("[]")]
    public void ParseZarRate_BadPayload_Throws(string json)
    {
        Assert.Throws<ExchangeRateUnavailableException>(() => ExchangeRateService.ParseZarRate(json));
    }
}
