using System.ComponentModel.DataAnnotations;

namespace GLMS.Api.Models;

public enum ContractStatus
{
    Draft = 0,
    Active = 1,
    Expired = 2,
    [Display(Name = "On Hold")]
    OnHold = 3
}

public enum ServiceLevel
{
    Standard = 0,
    Premium = 1,
    Express = 2
}

public enum RequestStatus
{
    Pending = 0,
    [Display(Name = "In Progress")]
    InProgress = 1,
    Completed = 2,
    Cancelled = 3
}
