using System.ComponentModel.DataAnnotations;

namespace GLMS.Web.Models;

// These classes describe the JSON the GLMS API sends and receives. The web app has its own copies
// (it never references the API project), which is what keeps the two services independent.

public enum ContractStatus
{
    Draft = 0,
    Active = 1,
    Expired = 2,
    [Display(Name = "On Hold")]
    OnHold = 3
}

public enum ServiceLevel
{
    Standard = 0,
    Premium = 1,
    Express = 2
}

public enum RequestStatus
{
    Pending = 0,
    [Display(Name = "In Progress")]
    InProgress = 1,
    Completed = 2,
    Cancelled = 3
}

public class LoginResult
{
    public string Token { get; set; } = string.Empty;
    public DateTime ExpiresAtUtc { get; set; }
    public string Username { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
}

public class ClientModel
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string ContactDetails { get; set; } = string.Empty;
    public string Region { get; set; } = string.Empty;
    public int ContractCount { get; set; }
}

public class ClientFormModel
{
    public int Id { get; set; }

    [Required, StringLength(150)]
    public string Name { get; set; } = string.Empty;

    [Required, StringLength(300)]
    [Display(Name = "Contact details")]
    public string ContactDetails { get; set; } = string.Empty;

    [Required, StringLength(100)]
    public string Region { get; set; } = string.Empty;
}

public class ContractModel
{
    public int Id { get; set; }
    public int ClientId { get; set; }
    public string ClientName { get; set; } = string.Empty;
    public string ClientRegion { get; set; } = string.Empty;
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public ContractStatus Status { get; set; }
    public ServiceLevel ServiceLevel { get; set; }
    public bool HasSignedAgreement { get; set; }
    public string? SignedAgreementFileName { get; set; }
    public DateTime? SignedAgreementUploadedAt { get; set; }
    public int RequestCount { get; set; }
    public bool CanRaiseServiceRequests { get; set; }
    public List<ContractStatus> AllowedNextStatuses { get; set; } = new();
}

public class ServiceRequestModel
{
    public int Id { get; set; }
    public int ContractId { get; set; }
    public string ClientName { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public decimal CostUsd { get; set; }
    public decimal ExchangeRate { get; set; }
    public decimal CostZar { get; set; }
    public RequestStatus Status { get; set; }
    public List<RequestStatus> AllowedNextStatuses { get; set; } = new();
    public DateTime CreatedAtUtc { get; set; }
}

public class ExchangeRateModel
{
    public decimal Rate { get; set; }
    public DateTime RetrievedAtUtc { get; set; }
}

public class DashboardModel
{
    public int ClientCount { get; set; }
    public int ContractCount { get; set; }
    public int DraftContracts { get; set; }
    public int ActiveContracts { get; set; }
    public int OnHoldContracts { get; set; }
    public int ExpiredContracts { get; set; }
    public int RequestCount { get; set; }
    public decimal TotalZar { get; set; }
}

public class ContractSearchCriteria
{
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public ContractStatus? Status { get; set; }
    public string? ClientName { get; set; }
    public int? ClientId { get; set; }
}

/// <summary>Everything needed to create or update a contract through the API.</summary>
public record ContractSubmission(
    int ClientId,
    DateTime StartDate,
    DateTime EndDate,
    ContractStatus Status,
    ServiceLevel ServiceLevel,
    IFormFile? SignedAgreement);
