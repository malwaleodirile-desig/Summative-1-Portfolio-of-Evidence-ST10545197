using GLMS.Api.Data;
using GLMS.Api.Dtos;
using GLMS.Api.Models;
using GLMS.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GLMS.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ContractsController : ControllerBase
{
    private readonly GlmsDbContext _db;
    private readonly IContractService _contracts;
    private readonly IFileStorageService _files;
    private readonly TimeProvider _time;

    public ContractsController(GlmsDbContext db, IContractService contracts, IFileStorageService files, TimeProvider time)
    {
        _db = db;
        _contracts = contracts;
        _files = files;
        _time = time;
    }

    /// <summary>
    /// Search contracts. All filters are optional: from/to (a contract matches when its period overlaps the
    /// range), status, clientId and clientName.
    /// </summary>
    [HttpGet]
    [ProducesResponseType(typeof(List<ContractDto>), StatusCodes.Status200OK)]
    public async Task<ActionResult<List<ContractDto>>> Search([FromQuery] ContractSearchCriteria criteria, CancellationToken ct)
    {
        if (criteria.From.HasValue && criteria.To.HasValue && criteria.From.Value.Date > criteria.To.Value.Date)
        {
            return BadRequest(new ProblemDetails
            {
                Status = StatusCodes.Status400BadRequest,
                Title = "Invalid date range",
                Detail = "The 'from' date cannot be after the 'to' date."
            });
        }

        var today = _time.GetLocalNow().Date;
        var contracts = await _contracts.SearchAsync(criteria, ct);
        return contracts.Select(c => c.ToDto(today)).ToList();
    }

    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(ContractDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ContractDto>> GetById(int id, CancellationToken ct)
    {
        await _contracts.RefreshExpiredContractsAsync(ct);
        var dto = await LoadDtoAsync(id, ct);
        return dto == null ? NotFound() : dto;
    }

    /// <summary>Create a contract. Send multipart/form-data; attach the signed agreement as a PDF.</summary>
    [HttpPost]
    [Consumes("multipart/form-data")]
    [ProducesResponseType(typeof(ContractDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<ContractDto>> Create([FromForm] ContractFormRequest request, CancellationToken ct)
    {
        // Managers can only create Draft contracts; an Admin approves (activates) them.
        if (request.Status != ContractStatus.Draft && !User.IsInRole(Roles.Admin))
        {
            return AdminOnly("Only an Admin can create a contract with a status other than Draft.");
        }

        var created = await _contracts.CreateAsync(request.ToEntity(), ToUpload(request.SignedAgreement), ct);
        var dto = await LoadDtoAsync(created.Id, ct);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, dto);
    }

    /// <summary>Update a contract's details (and optionally replace its signed agreement).</summary>
    [HttpPut("{id:int}")]
    [Consumes("multipart/form-data")]
    [ProducesResponseType(typeof(ContractDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ContractDto>> Update(int id, [FromForm] ContractFormRequest request, CancellationToken ct)
    {
        var existing = await _db.Contracts.AsNoTracking().FirstOrDefaultAsync(c => c.Id == id, ct);
        if (existing == null)
        {
            return NotFound();
        }

        if (request.Status != existing.Status && !User.IsInRole(Roles.Admin))
        {
            return AdminOnly("Only an Admin can change a contract's status.");
        }

        await _contracts.UpdateAsync(request.ToEntity(id), ToUpload(request.SignedAgreement), ct);
        return await LoadDtoAsync(id, ct) ?? (ActionResult<ContractDto>)NotFound();
    }

    /// <summary>Change a contract's status (approve, put on hold, expire). Admin only.</summary>
    [HttpPatch("{id:int}/status")]
    [Authorize(Roles = Roles.Admin)]
    [ProducesResponseType(typeof(ContractDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ContractDto>> UpdateStatus(int id, [FromBody] UpdateContractStatusRequest request,
        CancellationToken ct)
    {
        if (!await _db.Contracts.AnyAsync(c => c.Id == id, ct))
        {
            return NotFound();
        }

        await _contracts.ChangeStatusAsync(id, request.Status!.Value, ct);
        return await LoadDtoAsync(id, ct) ?? (ActionResult<ContractDto>)NotFound();
    }

    /// <summary>Upload or replace the signed agreement (PDF only).</summary>
    [HttpPost("{id:int}/agreement")]
    [Consumes("multipart/form-data")]
    [ProducesResponseType(typeof(ContractDto), StatusCodes.Status200OK)]
    public async Task<ActionResult<ContractDto>> UploadAgreement(int id, IFormFile file, CancellationToken ct)
    {
        if (!await _db.Contracts.AnyAsync(c => c.Id == id, ct))
        {
            return NotFound();
        }

        await _contracts.AttachAgreementAsync(id, ToUpload(file)!, ct);
        return await LoadDtoAsync(id, ct) ?? (ActionResult<ContractDto>)NotFound();
    }

    /// <summary>Download the signed agreement PDF.</summary>
    [HttpGet("{id:int}/agreement")]
    [Produces("application/pdf")]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> DownloadAgreement(int id, CancellationToken ct)
    {
        var contract = await _db.Contracts.AsNoTracking().FirstOrDefaultAsync(c => c.Id == id, ct);
        if (contract == null || !contract.HasSignedAgreement)
        {
            return NotFound();
        }

        var stream = _files.OpenRead(contract.SignedAgreementStoredName!);
        return stream == null ? NotFound() : File(stream, "application/pdf");
    }

    private ObjectResult AdminOnly(string detail) =>
        StatusCode(StatusCodes.Status403Forbidden, new ProblemDetails
        {
            Status = StatusCodes.Status403Forbidden,
            Title = "Not allowed",
            Detail = detail
        });

    private async Task<ContractDto?> LoadDtoAsync(int id, CancellationToken ct)
    {
        var contract = await _db.Contracts.AsNoTracking()
            .Include(c => c.Client)
            .Include(c => c.ServiceRequests)
            .FirstOrDefaultAsync(c => c.Id == id, ct);
        return contract?.ToDto(_time.GetLocalNow().Date);
    }

    private static AgreementUpload? ToUpload(IFormFile? file) =>
        file != null && !string.IsNullOrEmpty(file.FileName)
            ? new AgreementUpload(file.FileName, file.Length, file.OpenReadStream())
            : null;
}
