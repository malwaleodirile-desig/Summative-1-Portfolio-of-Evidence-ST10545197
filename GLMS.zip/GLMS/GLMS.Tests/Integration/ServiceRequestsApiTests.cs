using System.Net;
using System.Net.Http.Json;
using GLMS.Api.Dtos;
using GLMS.Api.Models;

namespace GLMS.Tests.Integration;

public class ServiceRequestsApiTests : IClassFixture<GlmsApiFactory>
{
    private readonly GlmsApiFactory _factory;

    public ServiceRequestsApiTests(GlmsApiFactory factory)
    {
        _factory = factory;
    }

    [Fact]
    public async Task GetServiceRequests_Returns200_WithSeededRequests()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);

        var response = await client.GetAsync("/api/servicerequests");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var items = await ApiTestHelpers.ReadAsync<List<ServiceRequestDto>>(response);
        Assert.True(items.Count >= 2);
    }

    [Fact]
    public async Task GetServiceRequests_FilteredByContract_ReturnsOnlyThatContractsRequests()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);
        var all = await ApiTestHelpers.ReadAsync<List<ServiceRequestDto>>(await client.GetAsync("/api/servicerequests"));
        var contractId = all.First().ContractId;

        var response = await client.GetAsync($"/api/servicerequests?contractId={contractId}");

        var filtered = await ApiTestHelpers.ReadAsync<List<ServiceRequestDto>>(response);
        Assert.NotEmpty(filtered);
        Assert.All(filtered, r => Assert.Equal(contractId, r.ContractId));
    }

    [Fact]
    public async Task PostServiceRequest_OnActiveContract_Returns201_AndSavesConvertedZarCost()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);
        var active = await ApiTestHelpers.FindContractAsync(client, ContractStatus.Active);

        var response = await client.PostAsJsonAsync("/api/servicerequests",
            new { contractId = active.Id, description = "Integration test shipment", costUsd = 100.00m });

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        Assert.NotNull(response.Headers.Location);
        var created = await ApiTestHelpers.ReadAsync<ServiceRequestDto>(response);
        Assert.Equal(100.00m, created.CostUsd);
        Assert.Equal(GlmsApiFactory.FixedRate, created.ExchangeRate);
        Assert.Equal(1850.00m, created.CostZar);
        Assert.Equal(RequestStatus.Pending, created.Status);

        var fetched = await client.GetAsync($"/api/servicerequests/{created.Id}");
        Assert.Equal(HttpStatusCode.OK, fetched.StatusCode);
    }

    [Fact]
    public async Task PostServiceRequest_OnExpiredContract_Returns400_AndNothingIsSaved()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);
        var expired = await ApiTestHelpers.FindContractAsync(client, ContractStatus.Expired);
        var before = (await ApiTestHelpers.ReadAsync<List<ServiceRequestDto>>(await client.GetAsync("/api/servicerequests"))).Count;

        var response = await client.PostAsJsonAsync("/api/servicerequests",
            new { contractId = expired.Id, description = "Should be rejected", costUsd = 50m });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        Assert.Contains("Expired", await response.Content.ReadAsStringAsync());
        var after = (await ApiTestHelpers.ReadAsync<List<ServiceRequestDto>>(await client.GetAsync("/api/servicerequests"))).Count;
        Assert.Equal(before, after);
    }

    [Fact]
    public async Task PostServiceRequest_OnHoldContract_Returns400()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);
        var onHold = await ApiTestHelpers.FindContractAsync(client, ContractStatus.OnHold);

        var response = await client.PostAsJsonAsync("/api/servicerequests",
            new { contractId = onHold.Id, description = "Should be rejected", costUsd = 50m });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        Assert.Contains("On Hold", await response.Content.ReadAsStringAsync());
    }

    [Fact]
    public async Task PostServiceRequest_OnDraftContract_Returns400()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);
        var draft = await ApiTestHelpers.FindContractAsync(client, ContractStatus.Draft);

        var response = await client.PostAsJsonAsync("/api/servicerequests",
            new { contractId = draft.Id, description = "Should be rejected", costUsd = 50m });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Theory]
    [InlineData(0)]
    [InlineData(-10)]
    public async Task PostServiceRequest_NonPositiveCost_Returns400(int cost)
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);
        var active = await ApiTestHelpers.FindContractAsync(client, ContractStatus.Active);

        var response = await client.PostAsJsonAsync("/api/servicerequests",
            new { contractId = active.Id, description = "Bad cost", costUsd = cost });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task PostServiceRequest_WhenCurrencyProviderIsDown_Returns503()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);
        var active = await ApiTestHelpers.FindContractAsync(client, ContractStatus.Active);
        _factory.Currency.Fail = true;
        try
        {
            var response = await client.PostAsJsonAsync("/api/servicerequests",
                new { contractId = active.Id, description = "Outage test", costUsd = 10m });

            Assert.Equal(HttpStatusCode.ServiceUnavailable, response.StatusCode);
        }
        finally
        {
            _factory.Currency.Fail = false;
        }
    }

    [Fact]
    public async Task PatchServiceRequestStatus_ValidTransition_Returns200()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);
        var active = await ApiTestHelpers.FindContractAsync(client, ContractStatus.Active);
        var created = await ApiTestHelpers.ReadAsync<ServiceRequestDto>(await client.PostAsJsonAsync("/api/servicerequests",
            new { contractId = active.Id, description = "Status test", costUsd = 20m }));

        var response = await ApiTestHelpers.PatchAsync(client, $"/api/servicerequests/{created.Id}/status", new { status = "InProgress" });

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        Assert.Equal(RequestStatus.InProgress, (await ApiTestHelpers.ReadAsync<ServiceRequestDto>(response)).Status);
    }

    [Fact]
    public async Task PatchServiceRequestStatus_InvalidTransition_Returns400()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);
        var active = await ApiTestHelpers.FindContractAsync(client, ContractStatus.Active);
        var created = await ApiTestHelpers.ReadAsync<ServiceRequestDto>(await client.PostAsJsonAsync("/api/servicerequests",
            new { contractId = active.Id, description = "Status test", costUsd = 20m }));

        var response = await ApiTestHelpers.PatchAsync(client, $"/api/servicerequests/{created.Id}/status", new { status = "Completed" });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task PatchServiceRequestStatus_Unknown_Returns404()
    {
        var client = await ApiTestHelpers.ManagerAsync(_factory);

        var response = await ApiTestHelpers.PatchAsync(client, "/api/servicerequests/999999/status", new { status = "InProgress" });

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }
}
