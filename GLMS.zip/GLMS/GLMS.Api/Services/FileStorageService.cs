namespace GLMS.Api.Services;

public record StoredFile(string StoredName, string OriginalName);

public interface IFileStorageService
{
    Task<StoredFile> SaveSignedAgreementAsync(string originalFileName, long length, Stream content,
        CancellationToken ct = default);

    Stream? OpenRead(string storedName);

    void Delete(string storedName);
}

/// <summary>Stores signed agreements on disk, outside wwwroot so they are only reachable through the app.</summary>
public class FileStorageService : IFileStorageService
{
    private readonly string _root;

    public FileStorageService(string rootPath)
    {
        _root = rootPath;
        Directory.CreateDirectory(_root);
    }

    public async Task<StoredFile> SaveSignedAgreementAsync(string originalFileName, long length, Stream content,
        CancellationToken ct = default)
    {
        FileValidator.ValidatePdf(originalFileName, length, content);

        var storedName = $"{Guid.NewGuid():N}.pdf";
        var path = Path.Combine(_root, storedName);

        await using (var target = File.Create(path))
        {
            await content.CopyToAsync(target, ct);
        }

        var cleanOriginal = Path.GetFileName(originalFileName);
        if (cleanOriginal.Length > 260)
        {
            cleanOriginal = cleanOriginal[^260..];
        }

        return new StoredFile(storedName, cleanOriginal);
    }

    public Stream? OpenRead(string storedName)
    {
        var path = SafePath(storedName);
        return File.Exists(path) ? File.OpenRead(path) : null;
    }

    public void Delete(string storedName)
    {
        var path = SafePath(storedName);
        if (File.Exists(path))
        {
            File.Delete(path);
        }
    }

    // Path.GetFileName strips any directory parts, so "../x" cannot escape the storage folder.
    private string SafePath(string storedName) => Path.Combine(_root, Path.GetFileName(storedName));
}
