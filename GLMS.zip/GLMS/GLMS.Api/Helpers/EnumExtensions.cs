using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Reflection;
using GLMS.Api.Models;

namespace GLMS.Api.Helpers;

public static class EnumExtensions
{
    /// <summary>Returns the [Display(Name)] of an enum value, or its name when none is set.</summary>
    public static string ToDisplayName(this Enum value)
    {
        var member = value.GetType().GetMember(value.ToString()).FirstOrDefault();
        var attribute = member?.GetCustomAttribute<DisplayAttribute>();
        return attribute?.GetName() ?? value.ToString();
    }

    public static string BadgeClass(this ContractStatus status) => status switch
    {
        ContractStatus.Active => "bg-success",
        ContractStatus.Draft => "bg-secondary",
        ContractStatus.OnHold => "bg-warning text-dark",
        ContractStatus.Expired => "bg-danger",
        _ => "bg-light text-dark"
    };

    public static string BadgeClass(this RequestStatus status) => status switch
    {
        RequestStatus.Pending => "bg-secondary",
        RequestStatus.InProgress => "bg-primary",
        RequestStatus.Completed => "bg-success",
        RequestStatus.Cancelled => "bg-danger",
        _ => "bg-light text-dark"
    };
}

public static class MoneyFormat
{
    public static string ToZar(this decimal amount) =>
        "R " + amount.ToString("N2", CultureInfo.InvariantCulture);

    public static string ToUsd(this decimal amount) =>
        "$ " + amount.ToString("N2", CultureInfo.InvariantCulture);
}
