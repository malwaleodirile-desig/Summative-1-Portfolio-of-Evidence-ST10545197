using System.Text;

namespace GLMS.Api.Data;

/// <summary>Builds a tiny but valid one-page PDF, used for seeded demo agreements.</summary>
public static class SamplePdf
{
    public static byte[] Create(string text)
    {
        // Keep the text PDF-safe (no brackets or backslashes).
        var safe = new string(text.Where(ch => ch >= 32 && ch < 127 && ch != '(' && ch != ')' && ch != '\\').ToArray());

        var sb = new StringBuilder();
        var offsets = new List<int>();

        void Obj(string body)
        {
            offsets.Add(sb.Length);
            sb.Append(offsets.Count).Append(" 0 obj\n").Append(body).Append("\nendobj\n");
        }

        sb.Append("%PDF-1.4\n");
        Obj("<< /Type /Catalog /Pages 2 0 R >>");
        Obj("<< /Type /Pages /Kids [3 0 R] /Count 1 >>");
        Obj("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>");
        var content = $"BT /F1 18 Tf 72 760 Td ({safe}) Tj ET";
        Obj($"<< /Length {content.Length} >>\nstream\n{content}\nendstream");
        Obj("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");

        var xrefPosition = sb.Length;
        sb.Append("xref\n0 6\n0000000000 65535 f \n");
        foreach (var offset in offsets)
        {
            sb.Append(offset.ToString("D10")).Append(" 00000 n \n");
        }
        sb.Append("trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n").Append(xrefPosition).Append("\n%%EOF");

        return Encoding.ASCII.GetBytes(sb.ToString());
    }
}
