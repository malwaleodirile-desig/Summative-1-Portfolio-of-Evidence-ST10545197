using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using GLMS.Api.Data;
using GLMS.Api.Dtos;
using GLMS.Api.Models;

namespace GLMS.Tests.Integration;

public static class ApiTestHelpers
{
    public static readonly JsonSerializerOptions Json = CreateOptions();

    private static JsonSerializerOptions CreateOptions()
    {
        var options = new JsonSerializerOptions(JsonSerializerDefaults.Web);
        options.Converters.Add(new JsonStringEnumConverter());
        return options;
    }

    /// <summary>Logs in through the real /api/auth/login endpoint and returns a client carrying the JWT.</summary>
    public static async Task<HttpClient> CreateClientAsync(GlmsApiFactory factory, string username, string password)
    {
        var client = factory.CreateClient();
        var response = await client.PostAsJsonAsync("/api/auth/login", new { username, password });
        response.EnsureSuccessStatusCode();

        var login = await response.Content.ReadFromJsonAsync<LoginResponse>(Json);
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", login!.Token);
        return client;
    }

    public static Task<HttpClient> AdminAsync(GlmsApiFactory factory) =>
        CreateClientAsync(factory, DbSeeder.AdminUsername, DbSeeder.AdminPassword);

    public static Task<HttpClient> ManagerAsync(GlmsApiFactory factory) =>
        CreateClientAsync(factory, DbSeeder.ManagerUsername, DbSeeder.ManagerPassword);

    public static Task<HttpResponseMessage> PatchAsync(HttpClient client, string url, object body) =>
        client.SendAsync(new HttpRequestMessage(HttpMethod.Patch, url) { Content = JsonContent.Create(body) });

    public static async Task<T> ReadAsync<T>(HttpResponseMessage response)
    {
        var value = await response.Content.ReadFromJsonAsync<T>(Json);
        Assert.NotNull(value);
        return value!;
    }

    public static async Task<List<ContractDto>> GetContractsAsync(HttpClient client, string query = "")
    {
        var response = await client.GetAsync("/api/contracts" + query);
        Assert.Equal(System.Net.HttpStatusCode.OK, response.StatusCode);
        return await ReadAsync<List<ContractDto>>(response);
    }

    public static async Task<ContractDto> FindContractAsync(HttpClient client, ContractStatus status)
    {
        var contracts = await GetContractsAsync(client, $"?status={status}");
        Assert.NotEmpty(contracts);
        return contracts.First();
    }

    public static MultipartFormDataContent ContractForm(int clientId, string status = "Draft",
        string? fileName = "agreement.pdf", byte[]? fileBytes = null,
        DateTime? start = null, DateTime? end = null)
    {
        var form = new MultipartFormDataContent
        {
            { new StringContent(clientId.ToString()), "ClientId" },
            { new StringContent((start ?? DateTime.Today).ToString("yyyy-MM-dd")), "StartDate" },
            { new StringContent((end ?? DateTime.Today.AddYears(1)).ToString("yyyy-MM-dd")), "EndDate" },
            { new StringContent(status), "Status" },
            { new StringContent("Premium"), "ServiceLevel" }
        };

        if (fileName != null)
        {
            var file = new ByteArrayContent(fileBytes ?? TestData.PdfBytes());
            file.Headers.ContentType = new MediaTypeHeaderValue("application/pdf");
            form.Add(file, "SignedAgreement", fileName);
        }

        return form;
    }

    public static async Task<int> FirstClientIdAsync(HttpClient client)
    {
        var response = await client.GetAsync("/api/clients");
        Assert.Equal(System.Net.HttpStatusCode.OK, response.StatusCode);
        var clients = await ReadAsync<List<ClientDto>>(response);
        return clients.First().Id;
    }
}
