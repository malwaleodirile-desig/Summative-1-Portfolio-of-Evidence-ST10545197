using GLMS.Api.Models;
using GLMS.Api.Services;
using Microsoft.EntityFrameworkCore;

namespace GLMS.Tests;

public class ContractServiceTests
{
    private static ContractService CreateService(Api.Data.GlmsDbContext db, InMemoryFileStorage files) =>
        new(db, files, new FixedTimeProvider(TestData.Now));

    private static Contract NewContract(int clientId, ContractStatus status = ContractStatus.Draft) => new()
    {
        ClientId = clientId,
        StartDate = new DateTime(2026, 10, 1),
        EndDate = new DateTime(2027, 9, 30),
        Status = status,
        ServiceLevel = ServiceLevel.Premium
    };

    [Fact]
    public async Task Create_DraftWithPdf_SavesContractAndStoresFile()
    {
        using var db = TestData.NewDb();
        var files = new InMemoryFileStorage();
        var client = await TestData.AddClientAsync(db);

        var created = await CreateService(db, files).CreateAsync(NewContract(client.Id), TestData.PdfUpload());

        Assert.True(created.HasSignedAgreement);
        Assert.Equal("agreement.pdf", created.SignedAgreementOriginalName);
        Assert.Single(files.Files);
        Assert.Equal(1, await db.Contracts.CountAsync());
    }

    [Fact]
    public async Task Create_WithExeAgreement_ThrowsInvalidFileAndSavesNothing()
    {
        using var db = TestData.NewDb();
        var files = new InMemoryFileStorage();
        var client = await TestData.AddClientAsync(db);

        await Assert.ThrowsAsync<InvalidFileException>(() =>
            CreateService(db, files).CreateAsync(NewContract(client.Id), TestData.ExeUpload()));

        Assert.Equal(0, await db.Contracts.CountAsync());
        Assert.Empty(files.Files);
    }

    [Fact]
    public async Task Create_ActiveWithoutAgreement_Throws()
    {
        using var db = TestData.NewDb();
        var client = await TestData.AddClientAsync(db);

        await Assert.ThrowsAsync<BusinessRuleException>(() =>
            CreateService(db, new InMemoryFileStorage()).CreateAsync(NewContract(client.Id, ContractStatus.Active), null));
    }

    [Fact]
    public async Task Create_ActiveWithPdf_Succeeds()
    {
        using var db = TestData.NewDb();
        var client = await TestData.AddClientAsync(db);

        var created = await CreateService(db, new InMemoryFileStorage())
            .CreateAsync(NewContract(client.Id, ContractStatus.Active), TestData.PdfUpload());

        Assert.Equal(ContractStatus.Active, created.Status);
    }

    [Fact]
    public async Task Create_EndDateBeforeStartDate_Throws()
    {
        using var db = TestData.NewDb();
        var client = await TestData.AddClientAsync(db);
        var contract = NewContract(client.Id);
        contract.EndDate = contract.StartDate.AddDays(-1);

        await Assert.ThrowsAsync<BusinessRuleException>(() =>
            CreateService(db, new InMemoryFileStorage()).CreateAsync(contract, null));
    }

    [Fact]
    public async Task Create_UnknownClient_Throws()
    {
        using var db = TestData.NewDb();

        await Assert.ThrowsAsync<BusinessRuleException>(() =>
            CreateService(db, new InMemoryFileStorage()).CreateAsync(NewContract(clientId: 999), null));
    }

    [Fact]
    public async Task ChangeStatus_DraftToActive_WithoutAgreement_Throws()
    {
        using var db = TestData.NewDb();
        var contract = await TestData.AddContractAsync(db, ContractStatus.Draft, withAgreement: false);

        await Assert.ThrowsAsync<BusinessRuleException>(() =>
            CreateService(db, new InMemoryFileStorage()).ChangeStatusAsync(contract.Id, ContractStatus.Active));
    }

    [Fact]
    public async Task ChangeStatus_DraftToActive_WithAgreement_Succeeds()
    {
        using var db = TestData.NewDb();
        var contract = await TestData.AddContractAsync(db, ContractStatus.Draft, withAgreement: true,
            end: new DateTime(2027, 12, 31));

        await CreateService(db, new InMemoryFileStorage()).ChangeStatusAsync(contract.Id, ContractStatus.Active);

        Assert.Equal(ContractStatus.Active, (await db.Contracts.SingleAsync()).Status);
    }

    [Fact]
    public async Task ChangeStatus_ExpiredToActive_IsNotAllowed()
    {
        using var db = TestData.NewDb();
        var contract = await TestData.AddContractAsync(db, ContractStatus.Expired);

        var ex = await Assert.ThrowsAsync<BusinessRuleException>(() =>
            CreateService(db, new InMemoryFileStorage()).ChangeStatusAsync(contract.Id, ContractStatus.Active));

        Assert.Contains("cannot move", ex.Message);
    }

    [Fact]
    public async Task ChangeStatus_ActiveToOnHold_Succeeds()
    {
        using var db = TestData.NewDb();
        var contract = await TestData.AddContractAsync(db, ContractStatus.Active);

        await CreateService(db, new InMemoryFileStorage()).ChangeStatusAsync(contract.Id, ContractStatus.OnHold);

        Assert.Equal(ContractStatus.OnHold, (await db.Contracts.SingleAsync()).Status);
    }

    [Fact]
    public async Task RefreshExpiredContracts_MarksOnlyOverdueActiveContracts()
    {
        using var db = TestData.NewDb();
        var client = await TestData.AddClientAsync(db);
        var overdue = await TestData.AddContractAsync(db, ContractStatus.Active, end: new DateTime(2026, 10, 12), client: client);
        var current = await TestData.AddContractAsync(db, ContractStatus.Active, end: new DateTime(2026, 10, 13), client: client);
        var draft = await TestData.AddContractAsync(db, ContractStatus.Draft, end: new DateTime(2026, 1, 1), client: client);

        var count = await CreateService(db, new InMemoryFileStorage()).RefreshExpiredContractsAsync();

        Assert.Equal(1, count);
        Assert.Equal(ContractStatus.Expired, (await db.Contracts.FindAsync(overdue.Id))!.Status);
        Assert.Equal(ContractStatus.Active, (await db.Contracts.FindAsync(current.Id))!.Status);
        Assert.Equal(ContractStatus.Draft, (await db.Contracts.FindAsync(draft.Id))!.Status);
    }

    [Fact]
    public async Task AttachAgreement_ReplacesOldFile()
    {
        using var db = TestData.NewDb();
        var files = new InMemoryFileStorage();
        var service = CreateService(db, files);
        var client = await TestData.AddClientAsync(db);
        var contract = await service.CreateAsync(NewContract(client.Id), TestData.PdfUpload("first.pdf"));
        var firstStoredName = contract.SignedAgreementStoredName!;

        await service.AttachAgreementAsync(contract.Id, TestData.PdfUpload("second.pdf"));

        var reloaded = await db.Contracts.AsNoTracking().SingleAsync();
        Assert.Equal("second.pdf", reloaded.SignedAgreementOriginalName);
        Assert.DoesNotContain(firstStoredName, files.Files.Keys);
        Assert.Single(files.Files);
    }

    [Fact]
    public async Task AttachAgreement_ExeFile_ThrowsAndKeepsExistingAgreement()
    {
        using var db = TestData.NewDb();
        var files = new InMemoryFileStorage();
        var service = CreateService(db, files);
        var client = await TestData.AddClientAsync(db);
        var contract = await service.CreateAsync(NewContract(client.Id), TestData.PdfUpload("first.pdf"));

        await Assert.ThrowsAsync<InvalidFileException>(() =>
            service.AttachAgreementAsync(contract.Id, TestData.ExeUpload()));

        var reloaded = await db.Contracts.AsNoTracking().SingleAsync();
        Assert.Equal("first.pdf", reloaded.SignedAgreementOriginalName);
        Assert.Single(files.Files);
    }

    [Fact]
    public async Task Update_InvalidStatusTransition_Throws()
    {
        using var db = TestData.NewDb();
        var contract = await TestData.AddContractAsync(db, ContractStatus.Expired);
        var edited = new Contract
        {
            Id = contract.Id,
            ClientId = contract.ClientId,
            StartDate = contract.StartDate,
            EndDate = contract.EndDate,
            Status = ContractStatus.Active,
            ServiceLevel = ServiceLevel.Standard
        };

        await Assert.ThrowsAsync<BusinessRuleException>(() =>
            CreateService(db, new InMemoryFileStorage()).UpdateAsync(edited, null));
    }

    [Fact]
    public async Task Search_AutoExpiresOverdueContractsBeforeFiltering()
    {
        using var db = TestData.NewDb();
        await TestData.AddContractAsync(db, ContractStatus.Active, end: new DateTime(2026, 10, 1));

        var expired = await CreateService(db, new InMemoryFileStorage())
            .SearchAsync(new ContractSearchCriteria { Status = ContractStatus.Expired });

        Assert.Single(expired);
    }
}
