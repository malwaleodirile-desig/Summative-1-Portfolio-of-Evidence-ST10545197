using GLMS.Api.Models;
using GLMS.Api.Services;
using Microsoft.EntityFrameworkCore;

namespace GLMS.Api.Data;

/// <summary>Adds demo users and demo data the first time the API runs against an empty database.</summary>
public static class DbSeeder
{
    // Demo credentials (documented in the README). Change them before any real deployment.
    public const string AdminUsername = "admin";
    public const string AdminPassword = "Admin@123";
    public const string ManagerUsername = "manager";
    public const string ManagerPassword = "Manager@123";

    public static async Task SeedAsync(GlmsDbContext db, IFileStorageService files, TimeProvider time,
        CancellationToken ct = default)
    {
        await SeedUsersAsync(db, ct);
        await SeedBusinessDataAsync(db, files, time, ct);
    }

    private static async Task SeedUsersAsync(GlmsDbContext db, CancellationToken ct)
    {
        if (await db.AppUsers.AnyAsync(ct))
        {
            return;
        }

        db.AppUsers.AddRange(
            new AppUser { Username = AdminUsername, PasswordHash = PasswordHasher.Hash(AdminPassword), Role = Roles.Admin },
            new AppUser { Username = ManagerUsername, PasswordHash = PasswordHasher.Hash(ManagerPassword), Role = Roles.Manager });
        await db.SaveChangesAsync(ct);
    }

    private static async Task SeedBusinessDataAsync(GlmsDbContext db, IFileStorageService files, TimeProvider time,
        CancellationToken ct)
    {
        if (await db.Clients.AnyAsync(ct))
        {
            return;
        }

        var today = time.GetLocalNow().Date;

        var clients = new[]
        {
            new Client { Name = "Atlas Freight GmbH", ContactDetails = "ops@atlasfreight.example | +49 40 555 0101", Region = "Europe" },
            new Client { Name = "Pacific Cargo Inc.", ContactDetails = "bookings@pacificcargo.example | +1 206 555 0144", Region = "North America" },
            new Client { Name = "Cape Harbour Traders", ContactDetails = "admin@capeharbour.example | +27 21 555 0188", Region = "Southern Africa" }
        };
        db.Clients.AddRange(clients);
        await db.SaveChangesAsync(ct);

        async Task<Contract> AddContract(Client client, int startOffsetDays, int endOffsetDays,
            ContractStatus status, ServiceLevel level, bool withAgreement)
        {
            var contract = new Contract
            {
                ClientId = client.Id,
                StartDate = today.AddDays(startOffsetDays),
                EndDate = today.AddDays(endOffsetDays),
                Status = status,
                ServiceLevel = level
            };

            if (withAgreement)
            {
                var bytes = SamplePdf.Create($"Signed agreement - {client.Name}");
                using var stream = new MemoryStream(bytes);
                var stored = await files.SaveSignedAgreementAsync(
                    $"{client.Name.Replace(' ', '_')}_agreement.pdf", bytes.Length, stream, ct);
                contract.SignedAgreementOriginalName = stored.OriginalName;
                contract.SignedAgreementStoredName = stored.StoredName;
                contract.SignedAgreementUploadedAt = DateTime.UtcNow;
            }

            db.Contracts.Add(contract);
            await db.SaveChangesAsync(ct);
            return contract;
        }

        var active1 = await AddContract(clients[0], -90, 275, ContractStatus.Active, ServiceLevel.Premium, true);
        var active2 = await AddContract(clients[1], -30, 335, ContractStatus.Active, ServiceLevel.Express, true);
        await AddContract(clients[2], 10, 375, ContractStatus.Draft, ServiceLevel.Standard, false);
        await AddContract(clients[0], -200, 60, ContractStatus.OnHold, ServiceLevel.Standard, true);
        await AddContract(clients[1], -400, -35, ContractStatus.Expired, ServiceLevel.Premium, true);

        db.ServiceRequests.AddRange(
            new ServiceRequest
            {
                ContractId = active1.Id,
                Description = "Container shipment Hamburg to Durban - 2 x 40ft",
                CostUsd = 4200m,
                ExchangeRate = 18.50m,
                CostZar = 77700m,
                Status = RequestStatus.InProgress,
                CreatedAt = DateTime.UtcNow.AddDays(-5)
            },
            new ServiceRequest
            {
                ContractId = active2.Id,
                Description = "Express air freight Seattle to Johannesburg",
                CostUsd = 1250.50m,
                ExchangeRate = 18.50m,
                CostZar = 23134.25m,
                Status = RequestStatus.Pending,
                CreatedAt = DateTime.UtcNow.AddDays(-1)
            });
        await db.SaveChangesAsync(ct);
    }
}
