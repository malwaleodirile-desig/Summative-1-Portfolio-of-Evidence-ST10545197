using System.Text.Json;

namespace GLMS.Api.Services;

public interface ICurrencyService
{
    /// <summary>Gets the current USD to ZAR exchange rate.</summary>
    Task<decimal> GetUsdToZarRateAsync(CancellationToken ct = default);
}

/// <summary>
/// Consumes the free ExchangeRate-API open endpoint (no API key needed) using HttpClient.
/// Example response: { "result": "success", "base_code": "USD", "rates": { "ZAR": 18.2, ... } }
/// </summary>
public class ExchangeRateService : ICurrencyService
{
    public const string RatesPath = "v6/latest/USD";

    private readonly HttpClient _http;

    public ExchangeRateService(HttpClient http)
    {
        _http = http;
    }

    public async Task<decimal> GetUsdToZarRateAsync(CancellationToken ct = default)
    {
        try
        {
            using var response = await _http.GetAsync(RatesPath, ct);
            response.EnsureSuccessStatusCode();
            var json = await response.Content.ReadAsStringAsync(ct);
            return ParseZarRate(json);
        }
        catch (HttpRequestException ex)
        {
            throw new ExchangeRateUnavailableException("Could not reach the exchange rate provider.", ex);
        }
        catch (TaskCanceledException ex) when (!ct.IsCancellationRequested)
        {
            throw new ExchangeRateUnavailableException("The exchange rate provider timed out.", ex);
        }
        catch (JsonException ex)
        {
            throw new ExchangeRateUnavailableException("The exchange rate response could not be read.", ex);
        }
    }

    /// <summary>Extracts the ZAR rate from the provider's JSON, throwing if it is missing or invalid.</summary>
    public static decimal ParseZarRate(string json)
    {
        using var doc = JsonDocument.Parse(json);
        var root = doc.RootElement;

        if (root.ValueKind != JsonValueKind.Object)
        {
            throw new ExchangeRateUnavailableException("The exchange rate response was not in the expected format.");
        }

        if (root.TryGetProperty("result", out var result) &&
            !(result.ValueKind == JsonValueKind.String && result.GetString() == "success"))
        {
            throw new ExchangeRateUnavailableException("The exchange rate provider reported an error.");
        }

        if (!root.TryGetProperty("rates", out var rates) || rates.ValueKind != JsonValueKind.Object)
        {
            throw new ExchangeRateUnavailableException("The response did not contain any exchange rates.");
        }

        if (!rates.TryGetProperty("ZAR", out var zar) || zar.ValueKind != JsonValueKind.Number)
        {
            throw new ExchangeRateUnavailableException("The response did not contain a ZAR rate.");
        }

        decimal rate;
        if (!zar.TryGetDecimal(out rate) || rate <= 0)
        {
            throw new ExchangeRateUnavailableException("The ZAR rate in the response was not valid.");
        }

        return rate;
    }
}
