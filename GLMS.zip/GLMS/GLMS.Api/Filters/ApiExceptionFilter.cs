using GLMS.Api.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace GLMS.Api.Filters;

/// <summary>Turns business-rule exceptions into clean JSON problem responses instead of 500 errors.</summary>
public class ApiExceptionFilter : IExceptionFilter
{
    private readonly ILogger<ApiExceptionFilter> _logger;

    public ApiExceptionFilter(ILogger<ApiExceptionFilter> logger)
    {
        _logger = logger;
    }

    public void OnException(ExceptionContext context)
    {
        switch (context.Exception)
        {
            case BusinessRuleException ex:
                context.Result = Problem(StatusCodes.Status400BadRequest, "A business rule was not met", ex.Message);
                context.ExceptionHandled = true;
                break;

            case ExchangeRateUnavailableException ex:
                _logger.LogWarning(ex, "Exchange rate provider unavailable.");
                context.Result = Problem(StatusCodes.Status503ServiceUnavailable,
                    "Exchange rate unavailable", "The exchange rate provider could not be reached. Please try again shortly.");
                context.ExceptionHandled = true;
                break;
        }
    }

    private static ObjectResult Problem(int status, string title, string detail)
    {
        var problem = new ProblemDetails { Status = status, Title = title, Detail = detail };
        return new ObjectResult(problem)
        {
            StatusCode = status,
            ContentTypes = { "application/problem+json" }
        };
    }
}
