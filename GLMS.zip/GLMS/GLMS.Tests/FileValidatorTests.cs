using System.Text;
using GLMS.Api.Services;

namespace GLMS.Tests;

public class FileValidatorTests
{
    private static MemoryStream PdfStream() => new(Encoding.ASCII.GetBytes("%PDF-1.4 sample"));

    [Theory]
    [InlineData("malware.exe")]
    [InlineData("installer.msi")]
    [InlineData("script.js")]
    [InlineData("photo.png")]
    [InlineData("report.docx")]
    [InlineData("archive.zip")]
    [InlineData("invoice.pdf.exe")]
    [InlineData("noextension")]
    public void ValidatePdf_RestrictedFileType_ThrowsInvalidFileException(string fileName)
    {
        using var stream = PdfStream();

        var ex = Assert.Throws<InvalidFileException>(() => FileValidator.ValidatePdf(fileName, stream.Length, stream));

        Assert.Contains("PDF", ex.Message);
    }

    [Theory]
    [InlineData("agreement.pdf")]
    [InlineData("AGREEMENT.PDF")]
    [InlineData("Signed Agreement (final).pdf")]
    public void ValidatePdf_ValidPdf_DoesNotThrow(string fileName)
    {
        using var stream = PdfStream();

        var exception = Record.Exception(() => FileValidator.ValidatePdf(fileName, stream.Length, stream));

        Assert.Null(exception);
    }

    [Fact]
    public void ValidatePdf_ExecutableRenamedToPdf_IsRejectedByContentCheck()
    {
        using var stream = new MemoryStream(Encoding.ASCII.GetBytes("MZ-this-is-an-exe"));

        Assert.Throws<InvalidFileException>(() => FileValidator.ValidatePdf("fake.pdf", stream.Length, stream));
    }

    [Fact]
    public void ValidatePdf_EmptyFile_Throws()
    {
        Assert.Throws<InvalidFileException>(() => FileValidator.ValidatePdf("empty.pdf", 0));
    }

    [Fact]
    public void ValidatePdf_FileTooLarge_Throws()
    {
        Assert.Throws<InvalidFileException>(() =>
            FileValidator.ValidatePdf("big.pdf", FileValidator.MaxFileSizeBytes + 1));
    }

    [Fact]
    public void ValidatePdf_MissingFileName_Throws()
    {
        Assert.Throws<InvalidFileException>(() => FileValidator.ValidatePdf("   ", 100));
    }

    [Fact]
    public void ValidatePdf_RewindsStreamAfterChecking()
    {
        using var stream = PdfStream();

        FileValidator.ValidatePdf("agreement.pdf", stream.Length, stream);

        Assert.Equal(0, stream.Position);
    }
}
