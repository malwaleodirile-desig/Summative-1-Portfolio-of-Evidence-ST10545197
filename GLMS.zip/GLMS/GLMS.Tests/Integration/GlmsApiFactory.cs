using GLMS.Api.Data;
using GLMS.Api.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace GLMS.Tests.Integration;

/// <summary>
/// Starts the real GLMS API (full middleware pipeline: JWT, routing, filters, Swagger) in memory,
/// swapping only the outside world: SQL Server becomes an in-memory database, the currency API a fixed
/// rate and the disk a memory store. Tests then call it over HTTP like any client would.
/// </summary>
public class GlmsApiFactory : WebApplicationFactory<Program>
{
    public const decimal FixedRate = 18.50m;

    private readonly string _databaseName = "glms-tests-" + Guid.NewGuid().ToString("N");

    public FakeCurrencyService Currency { get; } = new() { Rate = FixedRate };

    public InMemoryFileStorage Files { get; } = new();

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");

        builder.ConfigureTestServices(services =>
        {
            services.RemoveAll<DbContextOptions<GlmsDbContext>>();
            services.AddDbContext<GlmsDbContext>(options => options.UseInMemoryDatabase(_databaseName));

            services.RemoveAll<ICurrencyService>();
            services.AddSingleton<ICurrencyService>(Currency);

            services.RemoveAll<IFileStorageService>();
            services.AddSingleton<IFileStorageService>(Files);
        });
    }
}
