# Global Logistics Management System (GLMS) - Part 3: SOA, Docker and Integration Tests

TechMove Logistics (fictional client) manages international freight contracts, service requests and costs. In Part 2 this was a single ASP.NET Core MVC monolith. In Part 3 it is split into **independent services** that run in **Docker containers**:

```mermaid
flowchart LR
    U[Browser] -->|HTTP :5000| W[glms-frontend-web<br/>ASP.NET Core MVC]
    W -->|HttpClient + JWT| A[glms-backend-api<br/>ASP.NET Core Web API]
    U -.->|Swagger :5001/swagger| A
    A -->|EF Core / SQL| D[(sql-server-db<br/>SQL Server 2022)]
    A -->|HttpClient| X[External exchange rate API]
```

| Container | Project | Role |
|---|---|---|
| `sql-server-db` | `mcr.microsoft.com/mssql/server:2022-latest` | The database |
| `glms-backend-api` | `GLMS.Api` | The **only** component that talks to the database. Business logic, JWT security, Swagger |
| `glms-frontend-web` | `GLMS.Web` | Presentation layer. Has **no** database access; calls the API with `HttpClient` |

## Assignment checklist

| Requirement | Where |
|---|---|
| New ASP.NET Core Web API project that talks to the DB | `GLMS.Api` (EF Core + SQL Server, migrations in `GLMS.Api/Migrations`) |
| `GET /api/contracts` with filtering | `ContractsController.Search` (`from`, `to`, `status`, `clientId`, `clientName`) |
| `POST /api/contracts` | `ContractsController.Create` (multipart form with the signed PDF) |
| `PATCH /api/contracts/{id}/status` (approve/decline) | `ContractsController.UpdateStatus` (Admin only) |
| Other endpoints needed | Clients, service requests, currency rate, dashboard, auth, agreement upload/download, health |
| Swagger / OpenAPI | `http://localhost:5001/swagger` (Docker) or `http://localhost:5200/swagger` (local) |
| API reuses the Part 2 code and returns JSON | Services moved into `GLMS.Api/Services`; controllers return DTOs as JSON |
| MVC no longer connects to the DB; uses `HttpClient` | `GLMS.Web/Services/GlmsApiClient.cs` (typed `HttpClient`) |
| Authentication | JWT bearer tokens issued by the API; MVC signs users in with a cookie that carries the token |
| Integration tests that call the API | `GLMS.Tests/Integration` |
| Dockerfile for the API and the web app | `GLMS.Api/Dockerfile`, `GLMS.Web/Dockerfile` |
| `docker-compose.yml` with `sql-server-db`, `glms-backend-api`, `glms-frontend-web` on an internal network | `docker-compose.yml` (network `glms-net`) |
| Technical reflection report (PDF) | `GLMS_Part3_Technical_Reflection_Report.pdf` (submitted separately) |

## Quick start with Docker (recommended)

You need **Docker Desktop** running. From the folder that contains `docker-compose.yml`:

```
docker compose up --build
```

The first build downloads images and can take several minutes. When the logs settle:

| What | URL |
|---|---|
| **Web application** | http://localhost:5000 |
| **API Swagger UI** | http://localhost:5001/swagger |
| API health check | http://localhost:5001/health |
| SQL Server (for SSMS / Azure Data Studio) | `localhost,14333`, user `sa`, password from `.env` (default `Glms_Str0ng_Passw0rd`) |

The API applies the EF Core migration and seeds demo data on its first start (it retries until SQL Server is ready).

Stop everything with `docker compose down`. Add `-v` to also delete the database and uploaded files (`docker compose down -v`).

To change the SQL password or JWT secret, copy `.env.example` to `.env` and edit it.

### Demo accounts

| Username | Password | Role | Can do |
|---|---|---|---|
| `admin` | `Admin@123` | Admin | Everything, including approving contracts (status changes) and deleting clients |
| `manager` | `Manager@123` | Manager | Create clients, Draft contracts and service requests; cannot change contract status or delete clients |

## Running without Docker (Visual Studio)

1. Install SQL Server LocalDB (comes with Visual Studio). The API's default connection string in `GLMS.Api/appsettings.json` uses it.
2. Right-click the solution, choose **Configure Startup Projects**, select **Multiple startup projects** and set **GLMS.Api** and **GLMS.Web** to *Start*. (Or run `dotnet run --project GLMS.Api` and `dotnet run --project GLMS.Web` in two terminals.)
3. The API listens on http://localhost:5200 and the web app on http://localhost:5100. The web app finds the API through `Api:BaseUrl` in `GLMS.Web/appsettings.json`.

## Authentication and authorisation

1. The user signs in on the MVC login page.
2. MVC sends the credentials to `POST /api/auth/login`. The API checks the PBKDF2-hashed password and returns a signed **JWT** (valid for 60 minutes).
3. MVC stores the token inside its encrypted login cookie and attaches `Authorization: Bearer <token>` to every API call (`AuthTokenHandler`).
4. The API validates signature, issuer, audience and expiry on every request. Missing or invalid tokens get **401**; a valid token with the wrong role gets **403**.
5. If the token expires, the web app signs the user out and returns to the login page.

To try the API in Swagger: call `POST /api/auth/login`, copy the `token`, click **Authorize** and paste it.

## API endpoints

| Method and route | Who | Purpose |
|---|---|---|
| `POST /api/auth/login` | anyone | Exchange username and password for a JWT |
| `GET /api/auth/me` | signed in | Show the current user |
| `GET /api/contracts?from=&to=&status=&clientId=&clientName=` | signed in | Search contracts (date range overlaps the contract period) |
| `GET /api/contracts/{id}` | signed in | One contract |
| `POST /api/contracts` | signed in | Create (multipart/form-data; Managers can only create Draft) |
| `PUT /api/contracts/{id}` | signed in | Update details; only an Admin may change the status |
| `PATCH /api/contracts/{id}/status` | **Admin** | Approve, put on hold or expire |
| `POST /api/contracts/{id}/agreement` | signed in | Upload or replace the signed PDF |
| `GET /api/contracts/{id}/agreement` | signed in | Download the signed PDF |
| `GET /api/clients`, `GET /api/clients/{id}`, `POST`, `PUT /{id}` | signed in | Manage clients |
| `DELETE /api/clients/{id}` | **Admin** | Delete a client with no contracts |
| `GET /api/servicerequests?contractId=` | signed in | List service requests |
| `POST /api/servicerequests` | signed in | Raise a request (contract must be Active; USD converted to ZAR) |
| `PATCH /api/servicerequests/{id}/status` | signed in | Move a request through its workflow |
| `GET /api/currency/usd-zar` | signed in | Current USD to ZAR rate |
| `GET /api/dashboard` | signed in | Headline numbers |
| `GET /health` | anyone | Liveness check used by Docker |

Errors use RFC 7807 problem JSON (`title`, `detail`, `status`). Business-rule failures are **400**, missing items **404**, an unavailable exchange rate service **503**.

## Business rules (enforced by the API)

- A service request can only be created against an **Active** contract; Expired, On Hold and Draft are rejected and nothing is saved.
- An Active contract past its end date becomes **Expired** automatically.
- A contract cannot become Active without an uploaded signed agreement.
- Only genuine PDF files up to 10 MB are accepted (an `.exe`, or an `.exe` renamed to `.pdf`, is rejected).
- Contract transitions: Draft to Active; Active to On Hold or Expired; On Hold to Active or Expired; Expired is final.
- Request transitions: Pending to In Progress or Cancelled; In Progress to Completed or Cancelled.
- Cost in ZAR = round(USD x live rate, 2); the USD amount, rate and ZAR amount are all stored.

## Tests

```
dotnet test
```

or **Test > Run All Tests** in Visual Studio (open **Test Explorer** to take the screenshot).

| Group | What it covers |
|---|---|
| Unit tests (`GLMS.Tests/*.cs`) | Currency maths, PDF-only validation, file storage, exchange-rate parsing, LINQ contract search, workflow rules, contract and service-request services |
| Integration tests (`GLMS.Tests/Integration`) | Start the real API pipeline in memory and call it over HTTP: login and JWT, 401 without a token, 403 for the wrong role, `GET /api/contracts` returns 200 and JSON, filtering by status and date range, `POST` contract with a PDF and with an `.exe`, `PATCH` status as Admin and Manager, service requests on Active, Expired and On Hold contracts, currency endpoint, Swagger document, health |

The integration tests replace only the outside world (SQL Server becomes an in-memory database, the currency API a fixed rate), so they run anywhere, with no internet or Docker needed. This is what makes them suitable for the CI pipeline in `.github/workflows/ci.yml`, which builds, tests and then builds the Docker images on every push.

## Project structure

```
GLMS.sln
docker-compose.yml          3 containers on the glms-net network
.env.example                Settings for compose (SQL password, JWT key)
.github/workflows/ci.yml    Build + test + docker build on every push
Database/01_InitialCreate.sql   SQL migration script
GLMS.Api/                   Web API (owns the database)
  Controllers/  Dtos/  Filters/  Models/  Data/  Services/  Migrations/  Dockerfile
GLMS.Web/                   MVC client (no database access)
  Controllers/  Models/ (API JSON shapes)  Services/ (GlmsApiClient, AuthTokenHandler)  Views/  Dockerfile
GLMS.Tests/                 xUnit unit tests + Integration tests
```

## Database migrations

- EF Core migration: `GLMS.Api/Migrations/20261014120000_InitialCreate.cs` (applied automatically when the API starts).
- SQL script: `Database/01_InitialCreate.sql`.
- Regenerate from the model: `dotnet ef migrations add InitialCreate --project GLMS.Api`, then `dotnet ef migrations script --project GLMS.Api --output Database/01_InitialCreate.sql`.

## Suggested screenshots (Docker Desktop)

1. **Containers** tab showing `glms` with `sql-server-db`, `glms-backend-api` and `glms-frontend-web` all running (and healthy).
2. **Images** and **Volumes** tabs.
3. A container's **Logs** tab (for example the API logging "Database is ready.").
4. The browser showing the web app (http://localhost:5000) and Swagger (http://localhost:5001/swagger).
5. Test Explorer with all tests passing.

## Suggested video walkthrough

1. Show the solution structure: `GLMS.Api`, `GLMS.Web`, `GLMS.Tests`, the two Dockerfiles and `docker-compose.yml`. Explain why the UI and the service layer are separate.
2. Run `docker compose up --build`; show the three containers in Docker Desktop and explain the `glms-net` network and service-name addressing (`Server=sql-server-db`, `http://glms-backend-api:8080`).
3. Open Swagger, log in as `admin`, click **Authorize**, and try `GET /api/contracts` with a status filter.
4. Open the web app. Show that it redirects to login; sign in as `manager`, then try to change a contract status (not allowed) and sign in as `admin` to approve a Draft contract.
5. Create a contract with a PDF, then try an `.exe` to show rejection.
6. Create a service request: show the live ZAR calculation, then try the Expired and On Hold contracts.
7. Show how the MVC controller calls the API (`GlmsApiClient`) and how the JWT is attached (`AuthTokenHandler`).
8. Run the tests in Test Explorer and explain the integration tests.
9. Stop the API container and show the friendly error page in the web app (`docker stop glms-backend-api`), then start it again.

## Troubleshooting

- **API container keeps restarting at first start:** SQL Server needs a minute. The API retries for about 90 seconds. Check `docker compose logs glms-backend-api`.
- **SQL Server container exits:** the `sa` password must be strong (8+ characters with upper case, lower case and a digit).
- **Port already in use:** change the left-hand number in the `ports:` entries in `docker-compose.yml`.
- **Using .NET 9 or 10:** change `TargetFramework`, the package versions and the Docker base images (`sdk:8.0` and `aspnet:8.0`) together, then delete `GLMS.Api/Migrations` and run `dotnet ef migrations add InitialCreate --project GLMS.Api`.
- **The exchange rate shows as unavailable:** the container needs internet access to reach `https://open.er-api.com/v6/latest/USD`.

## Known limitations

- Demo credentials and the default JWT key are for development only; use `.env` secrets for anything real.
- Services listen on plain HTTP inside Docker; TLS would be added by a reverse proxy or cloud load balancer.
- Uploaded agreements live in a Docker volume on one host.
- Bootstrap and jQuery load from a CDN.

## Author

Odirile Malwale
