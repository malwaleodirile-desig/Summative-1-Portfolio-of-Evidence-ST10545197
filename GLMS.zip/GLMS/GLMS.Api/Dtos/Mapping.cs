using GLMS.Api.Models;
using GLMS.Api.Services;

namespace GLMS.Api.Dtos;

public static class Mapping
{
    public static ClientDto ToDto(this Client client) => new()
    {
        Id = client.Id,
        Name = client.Name,
        ContactDetails = client.ContactDetails,
        Region = client.Region,
        ContractCount = client.Contracts.Count
    };

    public static ContractDto ToDto(this Contract contract, DateTime today) => new()
    {
        Id = contract.Id,
        ClientId = contract.ClientId,
        ClientName = contract.Client?.Name ?? string.Empty,
        ClientRegion = contract.Client?.Region ?? string.Empty,
        StartDate = contract.StartDate,
        EndDate = contract.EndDate,
        Status = contract.Status,
        ServiceLevel = contract.ServiceLevel,
        HasSignedAgreement = contract.HasSignedAgreement,
        SignedAgreementFileName = contract.SignedAgreementOriginalName,
        SignedAgreementUploadedAt = contract.SignedAgreementUploadedAt,
        RequestCount = contract.ServiceRequests.Count,
        CanRaiseServiceRequests = contract.CanAcceptServiceRequests(today),
        AllowedNextStatuses = ContractWorkflow.AllowedNext(contract.Status).ToList()
    };

    public static ServiceRequestDto ToDto(this ServiceRequest request) => new()
    {
        Id = request.Id,
        ContractId = request.ContractId,
        ClientName = request.Contract?.Client?.Name ?? string.Empty,
        Description = request.Description,
        CostUsd = request.CostUsd,
        ExchangeRate = request.ExchangeRate,
        CostZar = request.CostZar,
        Status = request.Status,
        AllowedNextStatuses = RequestWorkflow.AllowedNext(request.Status).ToList(),
        CreatedAtUtc = DateTime.SpecifyKind(request.CreatedAt, DateTimeKind.Utc)
    };
}
