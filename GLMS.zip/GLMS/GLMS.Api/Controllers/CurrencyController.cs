using GLMS.Api.Dtos;
using GLMS.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GLMS.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class CurrencyController : ControllerBase
{
    private readonly ICurrencyService _currency;
    private readonly TimeProvider _time;

    public CurrencyController(ICurrencyService currency, TimeProvider time)
    {
        _currency = currency;
        _time = time;
    }

    /// <summary>Current USD to ZAR exchange rate, fetched from the external provider with HttpClient.</summary>
    [HttpGet("usd-zar")]
    [ProducesResponseType(typeof(ExchangeRateDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
    public async Task<ActionResult<ExchangeRateDto>> GetUsdToZar(CancellationToken ct)
    {
        var rate = await _currency.GetUsdToZarRateAsync(ct);
        return new ExchangeRateDto { Rate = rate, RetrievedAtUtc = _time.GetUtcNow().UtcDateTime };
    }
}
