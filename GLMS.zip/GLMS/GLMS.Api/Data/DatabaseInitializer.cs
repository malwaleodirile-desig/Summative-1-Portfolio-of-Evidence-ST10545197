using GLMS.Api.Services;
using Microsoft.EntityFrameworkCore;

namespace GLMS.Api.Data;

/// <summary>
/// Applies EF Core migrations and seeds demo data. Retries for a while because, in Docker,
/// the SQL Server container can take a little longer to start than the API.
/// </summary>
public static class DatabaseInitializer
{
    public static async Task InitializeAsync(IServiceProvider services, ILogger logger, CancellationToken ct = default)
    {
        const int maxAttempts = 30;

        for (var attempt = 1; ; attempt++)
        {
            try
            {
                using var scope = services.CreateScope();
                var db = scope.ServiceProvider.GetRequiredService<GlmsDbContext>();

                if (db.Database.IsRelational())
                {
                    await db.Database.MigrateAsync(ct);
                }
                else
                {
                    await db.Database.EnsureCreatedAsync(ct); // in-memory database used by integration tests
                }

                await DbSeeder.SeedAsync(
                    db,
                    scope.ServiceProvider.GetRequiredService<IFileStorageService>(),
                    scope.ServiceProvider.GetRequiredService<TimeProvider>(),
                    ct);

                logger.LogInformation("Database is ready.");
                return;
            }
            catch (Exception ex) when (attempt < maxAttempts && !ct.IsCancellationRequested)
            {
                logger.LogWarning(ex, "Database not ready yet (attempt {Attempt} of {Max}). Retrying in 3 seconds...",
                    attempt, maxAttempts);
                await Task.Delay(TimeSpan.FromSeconds(3), ct);
            }
        }
    }
}
