using System.Globalization;
using GLMS.Api.Services;

namespace GLMS.Tests;

public class CurrencyCalculatorTests
{
    private static decimal Dec(string value) => decimal.Parse(value, CultureInfo.InvariantCulture);

    [Theory]
    [InlineData("100", "18.50", "1850.00")]
    [InlineData("12.34", "18.4567", "227.76")]
    [InlineData("250.75", "17.9", "4488.43")]
    [InlineData("0", "18.50", "0.00")]
    [InlineData("0.005", "1", "0.01")]
    [InlineData("1", "18.123456", "18.12")]
    public void ConvertUsdToZar_ReturnsCorrectAmountForGivenRate(string usd, string rate, string expected)
    {
        var result = CurrencyCalculator.ConvertUsdToZar(Dec(usd), Dec(rate));

        Assert.Equal(Dec(expected), result);
    }

    [Fact]
    public void ConvertUsdToZar_NegativeAmount_Throws()
    {
        Assert.Throws<ArgumentOutOfRangeException>(() => CurrencyCalculator.ConvertUsdToZar(-1m, 18.5m));
    }

    [Theory]
    [InlineData("0")]
    [InlineData("-18.5")]
    public void ConvertUsdToZar_InvalidRate_Throws(string rate)
    {
        Assert.Throws<ArgumentOutOfRangeException>(() => CurrencyCalculator.ConvertUsdToZar(100m, Dec(rate)));
    }
}
