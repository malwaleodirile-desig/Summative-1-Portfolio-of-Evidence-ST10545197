using GLMS.Web.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GLMS.Web.Controllers;

public class HomeController : Controller
{
    private readonly IGlmsApiClient _api;

    public HomeController(IGlmsApiClient api)
    {
        _api = api;
    }

    public async Task<IActionResult> Index(CancellationToken ct) => View(await _api.GetDashboardAsync(ct));

    [AllowAnonymous]
    public IActionResult Error() => View();
}
