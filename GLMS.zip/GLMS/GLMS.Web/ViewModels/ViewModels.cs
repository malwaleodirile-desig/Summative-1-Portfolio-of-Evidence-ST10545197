using System.ComponentModel.DataAnnotations;
using GLMS.Web.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GLMS.Web.ViewModels;

public class LoginViewModel
{
    [Required]
    public string Username { get; set; } = string.Empty;

    [Required, DataType(DataType.Password)]
    public string Password { get; set; } = string.Empty;

    public string? ReturnUrl { get; set; }
}

public class ClientDetailsViewModel
{
    public ClientModel Client { get; set; } = new();
    public IReadOnlyList<ContractModel> Contracts { get; set; } = new List<ContractModel>();
}

public class ContractIndexViewModel
{
    public ContractSearchCriteria Criteria { get; set; } = new();
    public IReadOnlyList<ContractModel> Contracts { get; set; } = new List<ContractModel>();
}

public class ContractDetailsViewModel
{
    public ContractModel Contract { get; set; } = new();
    public IReadOnlyList<ServiceRequestModel> Requests { get; set; } = new List<ServiceRequestModel>();
}

public class ContractFormViewModel
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Please choose a client.")]
    [Display(Name = "Client")]
    public int? ClientId { get; set; }

    [Required(ErrorMessage = "Start date is required.")]
    [DataType(DataType.Date)]
    [Display(Name = "Start date")]
    public DateTime? StartDate { get; set; }

    [Required(ErrorMessage = "End date is required.")]
    [DataType(DataType.Date)]
    [Display(Name = "End date")]
    public DateTime? EndDate { get; set; }

    public ContractStatus Status { get; set; } = ContractStatus.Draft;

    [Display(Name = "Service level")]
    public ServiceLevel ServiceLevel { get; set; } = ServiceLevel.Standard;

    [Display(Name = "Signed agreement (PDF only)")]
    public IFormFile? SignedAgreement { get; set; }

    public string? ExistingAgreementName { get; set; }

    [ValidateNever]
    public List<SelectListItem> Clients { get; set; } = new();

    public ContractSubmission ToSubmission() =>
        new(ClientId!.Value, StartDate!.Value.Date, EndDate!.Value.Date, Status, ServiceLevel, SignedAgreement);
}

public class ServiceRequestCreateViewModel
{
    [Required(ErrorMessage = "Please choose a contract.")]
    [Display(Name = "Contract")]
    public int? ContractId { get; set; }

    [Required(ErrorMessage = "A description is required.")]
    [StringLength(1000)]
    public string Description { get; set; } = string.Empty;

    [Required(ErrorMessage = "Enter the cost in US dollars.")]
    [Range(typeof(decimal), "0.01", "1000000000", ErrorMessage = "Cost must be greater than zero.")]
    [Display(Name = "Cost (USD)")]
    public decimal? CostUsd { get; set; }

    /// <summary>Current USD to ZAR rate (from the API), used for the live preview.</summary>
    public decimal? ExchangeRate { get; set; }

    public string? RateError { get; set; }

    [ValidateNever]
    public List<SelectListItem> Contracts { get; set; } = new();
}
