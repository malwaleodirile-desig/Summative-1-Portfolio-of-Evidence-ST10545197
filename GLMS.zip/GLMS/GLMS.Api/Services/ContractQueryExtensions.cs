using GLMS.Api.Models;

namespace GLMS.Api.Services;

public class ContractSearchCriteria
{
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public ContractStatus? Status { get; set; }
    public string? ClientName { get; set; }
    public int? ClientId { get; set; }

    public bool HasAnyFilter =>
        From.HasValue || To.HasValue || Status.HasValue || ClientId.HasValue || !string.IsNullOrWhiteSpace(ClientName);
}

public static class ContractQueryExtensions
{
    /// <summary>
    /// LINQ filter used by the admin search. A contract matches the date range when its
    /// period (StartDate to EndDate) overlaps the requested From/To dates.
    /// </summary>
    public static IQueryable<Contract> ApplyFilters(this IQueryable<Contract> query, ContractSearchCriteria criteria)
    {
        if (criteria.Status.HasValue)
        {
            var status = criteria.Status.Value;
            query = query.Where(c => c.Status == status);
        }

        if (criteria.From.HasValue)
        {
            var from = criteria.From.Value.Date;
            query = query.Where(c => c.EndDate >= from);
        }

        if (criteria.To.HasValue)
        {
            var to = criteria.To.Value.Date;
            query = query.Where(c => c.StartDate <= to);
        }

        if (criteria.ClientId.HasValue)
        {
            var clientId = criteria.ClientId.Value;
            query = query.Where(c => c.ClientId == clientId);
        }

        if (!string.IsNullOrWhiteSpace(criteria.ClientName))
        {
            var term = criteria.ClientName.Trim();
            query = query.Where(c => c.Client!.Name.Contains(term));
        }

        return query;
    }
}
