using GLMS.Web.Models;
using GLMS.Web.Services;
using GLMS.Web.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace GLMS.Web.Controllers;

public class ClientsController : Controller
{
    private readonly IGlmsApiClient _api;

    public ClientsController(IGlmsApiClient api)
    {
        _api = api;
    }

    public async Task<IActionResult> Index(CancellationToken ct) => View(await _api.GetClientsAsync(ct));

    public async Task<IActionResult> Details(int id, CancellationToken ct)
    {
        var client = await _api.GetClientAsync(id, ct);
        if (client == null)
        {
            return NotFound();
        }

        var contracts = await _api.SearchContractsAsync(new ContractSearchCriteria { ClientId = id }, ct);
        return View(new ClientDetailsViewModel { Client = client, Contracts = contracts });
    }

    public IActionResult Create() => View(new ClientFormModel());

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(ClientFormModel model, CancellationToken ct)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        try
        {
            var created = await _api.CreateClientAsync(model, ct);
            TempData["Success"] = $"Client '{created.Name}' was created.";
            return RedirectToAction(nameof(Index));
        }
        catch (ApiValidationException ex)
        {
            ModelState.AddModelError(string.Empty, ex.Message);
            return View(model);
        }
    }

    public async Task<IActionResult> Edit(int id, CancellationToken ct)
    {
        var client = await _api.GetClientAsync(id, ct);
        if (client == null)
        {
            return NotFound();
        }

        return View(new ClientFormModel
        {
            Id = client.Id,
            Name = client.Name,
            ContactDetails = client.ContactDetails,
            Region = client.Region
        });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, ClientFormModel model, CancellationToken ct)
    {
        if (id != model.Id)
        {
            return NotFound();
        }

        if (!ModelState.IsValid)
        {
            return View(model);
        }

        try
        {
            var updated = await _api.UpdateClientAsync(id, model, ct);
            TempData["Success"] = $"Client '{updated.Name}' was updated.";
            return RedirectToAction(nameof(Index));
        }
        catch (ApiValidationException ex)
        {
            ModelState.AddModelError(string.Empty, ex.Message);
            return View(model);
        }
    }

    public async Task<IActionResult> Delete(int id, CancellationToken ct)
    {
        var client = await _api.GetClientAsync(id, ct);
        return client == null ? NotFound() : View(client);
    }

    [HttpPost, ActionName("Delete"), ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id, CancellationToken ct)
    {
        try
        {
            await _api.DeleteClientAsync(id, ct);
            TempData["Success"] = "The client was deleted.";
        }
        catch (ApiValidationException ex)
        {
            TempData["Error"] = ex.Message;
        }

        return RedirectToAction(nameof(Index));
    }
}
