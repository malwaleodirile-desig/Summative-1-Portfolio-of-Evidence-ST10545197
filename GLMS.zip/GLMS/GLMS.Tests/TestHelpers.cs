using System.Text;
using GLMS.Api.Data;
using GLMS.Api.Models;
using GLMS.Api.Services;
using Microsoft.EntityFrameworkCore;

namespace GLMS.Tests;

/// <summary>Currency service that returns a fixed rate (or throws) so no real HTTP call is made.</summary>
public class FakeCurrencyService : ICurrencyService
{
    public decimal Rate { get; set; } = 18.50m;
    public bool Fail { get; set; }
    public int Calls { get; private set; }

    public Task<decimal> GetUsdToZarRateAsync(CancellationToken ct = default)
    {
        Calls++;
        if (Fail)
        {
            throw new ExchangeRateUnavailableException("Simulated outage.");
        }

        return Task.FromResult(Rate);
    }
}

/// <summary>Clock fixed at a known moment so date rules are deterministic.</summary>
public class FixedTimeProvider : TimeProvider
{
    private readonly DateTimeOffset _now;

    public FixedTimeProvider(DateTimeOffset now) => _now = now;

    public override DateTimeOffset GetUtcNow() => _now;

    public override TimeZoneInfo LocalTimeZone => TimeZoneInfo.Utc;
}

/// <summary>File storage kept in memory; still runs the real PDF validation.</summary>
public class InMemoryFileStorage : IFileStorageService
{
    public Dictionary<string, byte[]> Files { get; } = new();

    public async Task<StoredFile> SaveSignedAgreementAsync(string originalFileName, long length, Stream content,
        CancellationToken ct = default)
    {
        FileValidator.ValidatePdf(originalFileName, length, content);

        using var ms = new MemoryStream();
        await content.CopyToAsync(ms, ct);
        var stored = Guid.NewGuid().ToString("N") + ".pdf";
        Files[stored] = ms.ToArray();
        return new StoredFile(stored, originalFileName);
    }

    public Stream? OpenRead(string storedName) =>
        Files.TryGetValue(storedName, out var bytes) ? new MemoryStream(bytes) : null;

    public void Delete(string storedName) => Files.Remove(storedName);
}

public static class TestData
{
    // "Today" for every test: 13 October 2026.
    public static readonly DateTimeOffset Now = new(2026, 10, 13, 10, 0, 0, TimeSpan.Zero);

    public static GlmsDbContext NewDb()
    {
        var options = new DbContextOptionsBuilder<GlmsDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;
        return new GlmsDbContext(options);
    }

    public static async Task<Client> AddClientAsync(GlmsDbContext db, string name = "Test Client")
    {
        var client = new Client { Name = name, ContactDetails = "test@example.com", Region = "Europe" };
        db.Clients.Add(client);
        await db.SaveChangesAsync();
        return client;
    }

    public static async Task<Contract> AddContractAsync(GlmsDbContext db, ContractStatus status,
        DateTime? start = null, DateTime? end = null, bool withAgreement = true, Client? client = null)
    {
        client ??= await AddClientAsync(db);
        var contract = new Contract
        {
            ClientId = client.Id,
            StartDate = start ?? new DateTime(2026, 1, 1),
            EndDate = end ?? new DateTime(2026, 12, 31),
            Status = status,
            ServiceLevel = ServiceLevel.Standard,
            SignedAgreementStoredName = withAgreement ? "existing.pdf" : null,
            SignedAgreementOriginalName = withAgreement ? "existing.pdf" : null
        };
        db.Contracts.Add(contract);
        await db.SaveChangesAsync();
        return contract;
    }

    public static byte[] PdfBytes() => Encoding.ASCII.GetBytes("%PDF-1.4\n% test document\n%%EOF");

    public static AgreementUpload PdfUpload(string fileName = "agreement.pdf")
    {
        var bytes = PdfBytes();
        return new AgreementUpload(fileName, bytes.Length, new MemoryStream(bytes));
    }

    public static AgreementUpload ExeUpload(string fileName = "malware.exe")
    {
        var bytes = Encoding.ASCII.GetBytes("MZ-not-a-pdf");
        return new AgreementUpload(fileName, bytes.Length, new MemoryStream(bytes));
    }
}
