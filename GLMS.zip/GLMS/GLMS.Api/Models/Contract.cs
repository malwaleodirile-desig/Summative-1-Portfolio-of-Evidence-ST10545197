using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace GLMS.Api.Models;

public class Contract
{
    public int Id { get; set; }

    public int ClientId { get; set; }

    [ValidateNever]
    public Client? Client { get; set; }

    [DataType(DataType.Date)]
    [Display(Name = "Start date")]
    public DateTime StartDate { get; set; }

    [DataType(DataType.Date)]
    [Display(Name = "End date")]
    public DateTime EndDate { get; set; }

    public ContractStatus Status { get; set; } = ContractStatus.Draft;

    [Display(Name = "Service level")]
    public ServiceLevel ServiceLevel { get; set; } = ServiceLevel.Standard;

    /// <summary>Original file name of the uploaded signed agreement (shown to users).</summary>
    public string? SignedAgreementOriginalName { get; set; }

    /// <summary>Generated, safe file name under App_Data/SignedAgreements.</summary>
    public string? SignedAgreementStoredName { get; set; }

    public DateTime? SignedAgreementUploadedAt { get; set; }

    [ValidateNever]
    public ICollection<ServiceRequest> ServiceRequests { get; set; } = new List<ServiceRequest>();

    public bool HasSignedAgreement => !string.IsNullOrEmpty(SignedAgreementStoredName);

    public bool IsPastEndDate(DateTime today) => EndDate.Date < today.Date;

    /// <summary>
    /// Business rule: service requests may only be raised against an Active contract
    /// whose end date has not passed. Draft, On Hold and Expired contracts are rejected.
    /// </summary>
    public bool CanAcceptServiceRequests(DateTime today) =>
        Status == ContractStatus.Active && !IsPastEndDate(today);
}
