using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using GLMS.Api.Data;
using GLMS.Api.Dtos;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace GLMS.Api.Services;

public class JwtOptions
{
    public string Key { get; set; } = string.Empty;
    public string Issuer { get; set; } = "GLMS.Api";
    public string Audience { get; set; } = "GLMS.Web";
    public int ExpiryMinutes { get; set; } = 60;
}

public interface IAuthService
{
    /// <summary>Returns a signed JWT for valid credentials, or null when the username or password is wrong.</summary>
    Task<LoginResponse?> LoginAsync(string username, string password, CancellationToken ct = default);
}

public class AuthService : IAuthService
{
    private readonly GlmsDbContext _db;
    private readonly JwtOptions _options;
    private readonly TimeProvider _time;

    public AuthService(GlmsDbContext db, IOptions<JwtOptions> options, TimeProvider time)
    {
        _db = db;
        _options = options.Value;
        _time = time;
    }

    public async Task<LoginResponse?> LoginAsync(string username, string password, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(username) || string.IsNullOrEmpty(password))
        {
            return null;
        }

        var name = username.Trim().ToLowerInvariant();
        var user = await _db.AppUsers.AsNoTracking().FirstOrDefaultAsync(u => u.Username == name, ct);

        if (user == null || !PasswordHasher.Verify(password, user.PasswordHash))
        {
            return null;
        }

        var now = _time.GetUtcNow().UtcDateTime;
        var expires = now.AddMinutes(_options.ExpiryMinutes);

        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
            new Claim("name", user.Username),
            new Claim("role", user.Role),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
        };

        var credentials = new SigningCredentials(
            new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_options.Key)), SecurityAlgorithms.HmacSha256);

        var token = new JwtSecurityToken(_options.Issuer, _options.Audience, claims,
            notBefore: now, expires: expires, signingCredentials: credentials);

        return new LoginResponse
        {
            Token = new JwtSecurityTokenHandler().WriteToken(token),
            ExpiresAtUtc = expires,
            Username = user.Username,
            Role = user.Role
        };
    }
}
