using GLMS.Api.Models;
using GLMS.Api.Services;

namespace GLMS.Tests;

public class WorkflowTests
{
    private static readonly DateTime Today = new(2026, 10, 13);

    [Theory]
    [InlineData(ContractStatus.Draft, false)]
    [InlineData(ContractStatus.Active, true)]
    [InlineData(ContractStatus.OnHold, false)]
    [InlineData(ContractStatus.Expired, false)]
    public void Contract_OnlyActiveStatusAcceptsServiceRequests(ContractStatus status, bool expected)
    {
        var contract = new Contract { Status = status, EndDate = Today.AddDays(30) };

        Assert.Equal(expected, contract.CanAcceptServiceRequests(Today));
    }

    [Fact]
    public void Contract_ActiveButPastEndDate_DoesNotAcceptServiceRequests()
    {
        var contract = new Contract { Status = ContractStatus.Active, EndDate = Today.AddDays(-1) };

        Assert.False(contract.CanAcceptServiceRequests(Today));
    }

    [Fact]
    public void Contract_ActiveOnEndDate_StillAcceptsServiceRequests()
    {
        var contract = new Contract { Status = ContractStatus.Active, EndDate = Today };

        Assert.True(contract.CanAcceptServiceRequests(Today));
    }

    [Theory]
    [InlineData(ContractStatus.Draft, ContractStatus.Active, true)]
    [InlineData(ContractStatus.Draft, ContractStatus.Expired, false)]
    [InlineData(ContractStatus.Active, ContractStatus.OnHold, true)]
    [InlineData(ContractStatus.Active, ContractStatus.Expired, true)]
    [InlineData(ContractStatus.Active, ContractStatus.Draft, false)]
    [InlineData(ContractStatus.OnHold, ContractStatus.Active, true)]
    [InlineData(ContractStatus.OnHold, ContractStatus.Expired, true)]
    [InlineData(ContractStatus.Expired, ContractStatus.Active, false)]
    [InlineData(ContractStatus.Expired, ContractStatus.OnHold, false)]
    [InlineData(ContractStatus.Active, ContractStatus.Active, true)]
    public void ContractWorkflow_TransitionRules(ContractStatus from, ContractStatus to, bool allowed)
    {
        Assert.Equal(allowed, ContractWorkflow.CanTransition(from, to));
    }

    [Theory]
    [InlineData(RequestStatus.Pending, RequestStatus.InProgress, true)]
    [InlineData(RequestStatus.Pending, RequestStatus.Cancelled, true)]
    [InlineData(RequestStatus.Pending, RequestStatus.Completed, false)]
    [InlineData(RequestStatus.InProgress, RequestStatus.Completed, true)]
    [InlineData(RequestStatus.Completed, RequestStatus.Pending, false)]
    [InlineData(RequestStatus.Cancelled, RequestStatus.InProgress, false)]
    public void RequestWorkflow_TransitionRules(RequestStatus from, RequestStatus to, bool allowed)
    {
        Assert.Equal(allowed, RequestWorkflow.CanTransition(from, to));
    }
}
