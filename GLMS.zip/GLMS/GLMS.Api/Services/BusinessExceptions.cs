namespace GLMS.Api.Services;

/// <summary>Raised when an action breaks a business rule (shown to the user as a friendly message).</summary>
public class BusinessRuleException : Exception
{
    public BusinessRuleException(string message) : base(message)
    {
    }
}

/// <summary>Raised when an uploaded file is not an acceptable signed agreement.</summary>
public class InvalidFileException : BusinessRuleException
{
    public InvalidFileException(string message) : base(message)
    {
    }
}

/// <summary>Raised when the external exchange rate provider cannot supply a usable rate.</summary>
public class ExchangeRateUnavailableException : Exception
{
    public ExchangeRateUnavailableException(string message, Exception? inner = null) : base(message, inner)
    {
    }
}
