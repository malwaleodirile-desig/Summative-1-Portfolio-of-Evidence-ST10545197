using GLMS.Api.Data;
using GLMS.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace GLMS.Api.Services;

public interface IServiceRequestService
{
    Task<ServiceRequest> CreateAsync(int contractId, string description, decimal costUsd, CancellationToken ct = default);
    Task ChangeStatusAsync(int requestId, RequestStatus newStatus, CancellationToken ct = default);
}

public class ServiceRequestService : IServiceRequestService
{
    private readonly GlmsDbContext _db;
    private readonly ICurrencyService _currency;
    private readonly TimeProvider _time;

    public ServiceRequestService(GlmsDbContext db, ICurrencyService currency, TimeProvider time)
    {
        _db = db;
        _currency = currency;
        _time = time;
    }

    public async Task<ServiceRequest> CreateAsync(int contractId, string description, decimal costUsd,
        CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(description))
        {
            throw new BusinessRuleException("A description is required.");
        }

        if (costUsd <= 0)
        {
            throw new BusinessRuleException("The cost in USD must be greater than zero.");
        }

        var contract = await _db.Contracts.FirstOrDefaultAsync(c => c.Id == contractId, ct)
                       ?? throw new BusinessRuleException("The selected contract does not exist.");

        var today = _time.GetLocalNow().Date;

        // Automated tracking: an Active contract past its end date is really Expired.
        if (contract.Status == ContractStatus.Active && contract.IsPastEndDate(today))
        {
            contract.Status = ContractStatus.Expired;
            await _db.SaveChangesAsync(ct);
        }

        // Core workflow rule: only valid, Active contracts can receive service requests.
        if (!contract.CanAcceptServiceRequests(today))
        {
            throw new BusinessRuleException(contract.Status switch
            {
                ContractStatus.Expired => "Service requests cannot be raised against an Expired contract.",
                ContractStatus.OnHold => "Service requests cannot be raised against a contract that is On Hold.",
                ContractStatus.Draft => "Service requests cannot be raised against a Draft contract. Activate it first.",
                _ => "Service requests can only be raised against an Active contract."
            });
        }

        var rate = await _currency.GetUsdToZarRateAsync(ct);
        var costZar = CurrencyCalculator.ConvertUsdToZar(costUsd, rate);

        var request = new ServiceRequest
        {
            ContractId = contract.Id,
            Description = description.Trim(),
            CostUsd = costUsd,
            ExchangeRate = rate,
            CostZar = costZar,
            Status = RequestStatus.Pending,
            CreatedAt = _time.GetUtcNow().UtcDateTime
        };

        _db.ServiceRequests.Add(request);
        await _db.SaveChangesAsync(ct);
        return request;
    }

    public async Task ChangeStatusAsync(int requestId, RequestStatus newStatus, CancellationToken ct = default)
    {
        var request = await _db.ServiceRequests.FirstOrDefaultAsync(r => r.Id == requestId, ct)
                      ?? throw new BusinessRuleException("The service request could not be found.");

        if (!RequestWorkflow.CanTransition(request.Status, newStatus))
        {
            throw new BusinessRuleException(
                $"A service request cannot move from {request.Status} to {newStatus}.");
        }

        request.Status = newStatus;
        await _db.SaveChangesAsync(ct);
    }
}
